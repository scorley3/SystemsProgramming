/**
 * deepfried_dd
 * CS 341 - Fall 2023
 */
#include "format.h"
#include <bits/time.h>
#include <inttypes.h>
#include <signal.h>
#include <stddef.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <math.h>

// collaborated with bestie alexis
//
static int flag = 0;
extern char *optarg;
static struct timespec startTime, stopTime;

void change_flag(int sig) {
    if (sig == SIGUSR1) flag = 1;
}

void print_report(size_t full_blocks_read, size_t partial_blocks_read, size_t copy_size) {
    int clock_end_time = clock_gettime(CLOCK_REALTIME, &stopTime);
    if (clock_end_time == -1) {
        perror("time::");
        exit(1);
    }
    double time_elapsed = (stopTime.tv_sec - startTime.tv_sec) + (double) (stopTime.tv_nsec - startTime.tv_nsec) / (double) (1000000000);
    
    print_status_report(full_blocks_read, partial_blocks_read, 
                        full_blocks_read, partial_blocks_read,
                        copy_size, time_elapsed);
}

int main(int argc, char **argv) {
    signal(SIGUSR1, change_flag);

    FILE *input = stdin;
    FILE *output = stdout;

    // default opt status
    int optStatus = 0;
    int blockSize = 512;
    // default block num is 1
    int blockCount = 0;
    // both default skips are 1
    int inputSkip = 0;
    int outputSKip = 0;

    // keep looking for options while we find more
    // the option gets stored in optarg
    while ((optStatus = getopt(argc, argv, "b:o:i:c:p:k:")) != -1) {
        switch (optStatus) {
            case 'b':
                blockSize = atol(optarg); // convert optarg to integer
                break;
            case 'o': // output file
                output = fopen(optarg, "w+"); // open output file
                if (!output) {
                    print_invalid_output(optarg);
                    exit(1);
                }
                break;
            case 'i': // input file
                input = fopen(optarg, "r"); // open input file
                if (!input) {
                    print_invalid_input(optarg);
                    exit(1);
                }
                break;
            case 'c':
                blockCount = atol(optarg); // convert optarg to integer
                break;
            case 'p':
                inputSkip = atol(optarg); // convert optarg to integer
                break;
            case 'k':
                outputSKip = atol(optarg);
                break;
            default: 
                break;
        }
    }

    if (clock_gettime(CLOCK_REALTIME, &startTime) == -1) {
        perror("time::");
        exit(1);
    }

    // copy size is total number of bytes 
    size_t fullRead = 0, partialRead = 0, copySize = 0, bytes = 0;

    fseek(input, inputSkip * blockSize, SEEK_SET); 
    fseek(output, outputSKip * blockSize, SEEK_SET);

    char buf[blockSize];

    // improvemnt on yesterday's commit -- can use fread whether it is 
    // stdin or a file
    while((bytes = fread(buf, 1, blockSize, input)) > 0) {
        if (bytes < (unsigned int) blockSize) { // add partial block 
            partialRead++; 
            copySize += bytes; 
            fwrite(buf, bytes, 1, output);
        }
        else {
            fflush(input); // flush because full block 
            fwrite(buf, blockSize, 1, output);
            fullRead++; 
            copySize += blockSize; // add whole block 
        }

        if (flag) {
            print_report(fullRead, partialRead, copySize);
            flag = 0;
        }

        size_t blocksRead = fullRead + partialRead; 
        //printf("status: %d, %lu, %lu", blockCount, blocksRead, bytes);
        if (blockCount && blocksRead >= (unsigned int) blockCount) break;
    }

    print_report(fullRead, partialRead, copySize);
    
    fclose(input);
    fclose(output);


}
