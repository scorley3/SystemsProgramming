/**
 * vector
 * CS 341 - Fall 2023
 */
#include "sstring.h"
#include "assert.h"
#include "string.h"

#include "stdio.h"

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

int main(int argc, char *argv[]) {
    assert(argc == 1); 
    assert(*argv);
    char* s = "DOG"; 
    char* t = "CAT";

    sstring *s1 = cstr_to_sstring(s); 
    sstring *t1 = cstr_to_sstring(t); 

    int l = sstring_append(s1, t1); 
    DEBUG_PRINT("%s \n", sstring_to_cstr(s1));
    DEBUG_PRINT("l is %d \n", l);
    assert(l == 6);

    assert(strcmp(sstring_to_cstr(cstr_to_sstring("dog")), "dog") == 0);

    sstring *repl = cstr_to_sstring("DOGDOGDOGDOGDOGDOGDOG"); 
    assert(strcmp(sstring_to_cstr(repl), "DOGDOGDOGDOGDOGDOGDOG") == 0);
    int success = sstring_substitute(repl, 5, "DOGDOG", "CAT"); 
    DEBUG_PRINT("%s\n", sstring_to_cstr(repl));
    assert(strcmp(sstring_to_cstr(repl), "DOGDOGCATDOGDOGDOG") == 0);
    assert(success == 0);

    int failure = sstring_substitute(repl, 2, "bug", "sad");
    assert(failure == -1);

    char *dog = sstring_slice(repl, 4, 7); 
    assert(strcmp(dog, "OGC") == 0);

    sstring *a = cstr_to_sstring("car,dog,silly,woof,ah");
    vector *vect = sstring_split(a, ',');
    
    DEBUG_PRINT("%s\n", (char*)vector_get(vect, 0));
    DEBUG_PRINT("%s\n", (char*)vector_get(vect, 1));

    DEBUG_PRINT("%s\n", (char*)vector_get(vect, 2));

    assert(strcmp(vector_get(vect, 2), "silly") == 0);


    sstring *b = cstr_to_sstring("car,dog,,silly,woof,ah");
    vector *bb = sstring_split(b, ',');
    assert(strcmp(vector_get(bb, 2), "") == 0);


    return 0;
}
