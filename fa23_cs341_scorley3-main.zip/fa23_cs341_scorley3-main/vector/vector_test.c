/**
 * vector
 * CS 341 - Fall 2023
 */
#include "vector.h"
#include "callbacks.h"
#include "assert.h"
#include "stdio.h"

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif


int main(int argc, char *argv[]) {
    assert(argc); 
    assert(argv);
    // Append 1 Million Elements: Push back 1 million elements, then get each of them to check for correctness.
    vector *one = vector_create(double_copy_constructor, double_destructor, double_default_constructor);
    size_t a; 
    for (a = 0; a < 1000000; a++) {
        double d = a;
        vector_push_back(one, (void*)&d);
        assert(vector_size(one) == a + 1);
    }

    DEBUG_PRINT("%s\n", "SUCCESS -- push back a million elements");

    for (a = 0; a < 1000000; a++) {
        assert(*(double *)vector_get(one, a) == a);
    }

    DEBUG_PRINT("%s\n", "SUCCESS -- check one million elements");

    for (a = 500; a < 1000; a++) {
        vector_erase(one, 500); 
        assert(vector_size(one) == 1000499 - a);
        assert(*(double *)vector_get(one, 500) == a + 1);
        DEBUG_PRINT("%s %lu \n", "SUCCESS -- erase an element new should be ", a + 1);
    }

    for (a = 0; a < 500; a++) {
        assert(*(double *) vector_get(one, a) == a);
    }

    for (a = 500; a < 1000; a++) {
        assert(*(double *) vector_get(one, a) == a + 500);
    }
    
    DEBUG_PRINT("%s\n", "SUCCESS -- erase and check elements");

    vector *this = vector_create(int_copy_constructor, int_destructor, int_default_constructor);
    assert(vector_size(this) == 0);
    assert(vector_empty(this));

    DEBUG_PRINT("%s\n", "SUCCESS -- empty vector tests");

    int p = 2;
    vector_push_back(this, (void *) &p);
    assert(!vector_empty(this));
    assert(vector_size(this) == 1);
    assert(vector_capacity(this) == 8);

    DEBUG_PRINT("%s\n", "SUCCESS -- add one element");

    int n = 2;
    vector_push_back(this, (void*)&n); 
    assert(vector_size(this) == 2); 

    DEBUG_PRINT("%s\n", "SUCCESS -- add second element");

    int g = 3;
    vector_insert(this, 1, (void *)&g); 

    assert(vector_size(this) == 3); 
    assert(vector_capacity(this) == 8);
    assert(*(int *)(vector_get(this, 0)) == 2);
    assert(*(int *)(vector_get(this, 1)) == 3);
    assert(*(int *)(vector_get(this, 2)) == 2);
    assert(*(int**)vector_back(this) == (int*)vector_get(this, vector_size(this) - 1));
    assert(*(int**)vector_front(this) == (int*)vector_get(this, 0));

    DEBUG_PRINT("%s\n", "SUCCESS -- insert one element");
    size_t expected_size = 3;
    int i; 
    for (i = 0; i < 100; i++) {
        int z = 100;
        vector_push_back(this, (void *) &z);

        expected_size++;
        DEBUG_PRINT("current vector size: %zu\n", vector_size(this));
        assert(vector_size(this) == expected_size);
    }

    assert(vector_size(this) == 103); 
    
    int j;
    for (j = 0; j < 100; j++) {
	    assert(*(int *)(vector_get(this, j + 3)) == 100);
    }

    DEBUG_PRINT("%s\n", "SUCCESS -- push back 100 elements");

    for (j = 0; j < 100; j++) {
        vector_erase(this, 0);
        assert(vector_size(this) == (unsigned long)102 - j);
        DEBUG_PRINT("%s\n", "SUCCESS -- removed an element");
    }

    DEBUG_PRINT("%s\n", "SUCCESS -- erase 100 elements");

    vector_clear(this);
    vector_clear(one);
    assert(vector_size(this) == 0);
    assert(vector_size(one) == 0);
    // int y = 1; 
    // vector_push_back(this, (void *)&y);
    // free(this);
    // free(one);
    vector *v = vector_create(unsigned_char_copy_constructor, unsigned_char_destructor, unsigned_char_default_constructor);
    vector_reserve(v, 17); 
    assert(vector_capacity(v) == 32);

    DEBUG_PRINT("%s", "SUCCESS -- clear vector");

    vector_destroy(this);
    vector_destroy(one);
    vector_destroy(v);

    return 0;
}
