/**
 * vector
 * CS 341 - Fall 2023
 */
#include "sstring.h"
#include "vector.h"
#include "stdio.h"

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <assert.h>
#include <string.h>

struct sstring {
    // Anything you want
    char* string; 
    size_t length; 
    size_t capacity; 
};

sstring *cstr_to_sstring(const char *input) {
    sstring *this = malloc(sizeof(sstring));
    size_t len = strlen(input);
    this->string = malloc(len + 1);
    strcpy(this->string, input);
    this->length = len;
    this->capacity = len; 
    return this;
}

char *sstring_to_cstr(sstring *input) {
    char* str = malloc(input->length + 1);
    strcpy(str, input->string);
    return str;
}

int sstring_append(sstring *this, sstring *addition) {
    while (this->capacity < this->length + addition->length + 1) {
        this->string = realloc(this->string, this->capacity * 2);
        this->capacity *= 2; 
    }

    strcat(this->string, addition->string);
    DEBUG_PRINT("%s", this->string);
    this->length = strlen(this->string);
    return this->length;
}

vector *sstring_split(sstring *this, char delimiter) {
    vector *vect = string_vector_create();
    int start = 0; 
    char * loc = NULL;

    while ((loc = strchr(this->string + start, delimiter)) != NULL) {
        size_t length = loc - (this->string + start);

        char * chunk = sstring_slice(this, start, start + length);
        vector_push_back(vect, chunk); 
        start = loc - this->string + 1; 
    }
    
    return vect;
}

int sstring_substitute(sstring *this, size_t offset, char *target,
                       char *substitution) {
    // your code goes here
    assert(this);
    assert(offset >= 0);
    assert(target);
    assert(substitution);

    char * haystack = this->string;
    char * needle = strstr(this->string + offset, target); 
    int dist = needle - haystack;
    if (!needle) return -1;

    this->string = malloc(this->length + strlen(substitution) - strlen(target) + 1);
    *(this->string) = 0;

    strncat(this->string, haystack, needle - haystack); 

    strcat(this->string, substitution);

    haystack += dist + strlen(target);

    strcat(this->string, haystack);

    free(haystack - dist - strlen(target));
    
    return 0;


}

char *sstring_slice(sstring *this, int start, int end) {
    assert(start <= end); 
    char *slice = malloc(end - start + 1);
    strncpy(slice, this->string + start, end - start);
    return slice;
}

void sstring_destroy(sstring *this) {
    free(this->string);
    this->string = 0;
    free(this);
}
