/**
 * mapreduce
 * CS 341 - Fall 2023
 */
#include "core/utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

void closePipes(int *pipes, int pipeCount) {
    for (int i = 0; i < pipeCount; i++) {
        close(pipes[i]);
    }
}

void waitProc(pid_t *processes, int numProcesses, char *procName) {
    int status = 0;
    for (int i = 0; i < numProcesses; i++) {
        waitpid(processes[i], &status, 0);
        if (WIFEXITED(status)) {
            status = WEXITSTATUS(status);
            if (status) {
                print_nonzero_exit_status(procName, status);
            }
        }
    }

}

int main(int argc, char **argv) {
    // print usage if wrong # of arguments
    if (argc != 6) {
        print_usage();
    }

    // split arguments --> ./mr input output mapper reducer num
    char *inputFile = argv[1];
    char *outputFile = argv[2];
    char *mapper = argv[3];
    char *reducer = argv[4];
    int mapperCount = atoi(argv[5]);

    // Create an input pipe for each mapper.
    int pipes[mapperCount * 2];
    int i = 0;
    for (; i < mapperCount; i++) {
        pipe(pipes + i * 2);
    }

    // Create one input pipe for the reducer.
    int reduce_pipe[2];
    pipe(reduce_pipe);

pid_t splitter_processes[mapperCount];
    for (i = 0; i < mapperCount; i++) {
        splitter_processes[i] = fork();
        if (splitter_processes[i] == 0) {
            // we are the child

            // put the out of the pipe into fd 1
            if (dup2(pipes[2 * i + 1], 1) == -1) {
                exit(1);
            }

            closePipes(pipes, mapperCount * 2);
            closePipes(reduce_pipe, 2);
            char *splitter = "splitter";
            char index[20];
            sprintf(index, "%d", i);
            if (execl(splitter, splitter, inputFile, argv[5], index, NULL) == -1)
            exit(1);
        }
        else if (splitter_processes[i] == -1) exit(1);

    }

    // Start all the mapper processes.
    pid_t mapper_processes[mapperCount];
    for (i = 0; i < mapperCount; i++) {
        mapper_processes[i] = fork();
        if (mapper_processes[i] == 0) {
            // we are the child
            // duplicate in of mapper pipe and out of reducer
            if (dup2(pipes[2 * i], 0) == -1 || dup2(reduce_pipe[1], 1) == -1) {
                exit(1);
            }

            closePipes(pipes, mapperCount * 2);
            closePipes(reduce_pipe, 2);
            execl(mapper, mapper, NULL);
            exit(1);
        }
        else if (mapper_processes[i] == -1) exit(1);
    }

    // Start a splitter process for each mapper.

    // Start the reducer process.
    pid_t reducer_process = fork();
    if (reducer_process == 0) {
        // we are the child
        // dup reducer pipe in
        FILE *output = freopen(outputFile, "w+", stdout);

        if (dup2(reduce_pipe[0], 0) == -1 || !output) {
            exit(1);
        }

        closePipes(pipes, mapperCount * 2);
        closePipes(reduce_pipe, 2);
        execl(reducer, reducer, NULL);
        exit(1);
    }
    else if (reducer_process == -1) exit(1);
    else {
        closePipes(pipes, mapperCount * 2);
        closePipes(reduce_pipe, 2);
    }

    // Wait for the reducer to finish.
    waitProc(mapper_processes, mapperCount, mapper);
    waitProc(splitter_processes, mapperCount, "splitter");
    waitProc(&reducer_process, 1, reducer);

    // Print nonzero subprocess exit codes.

    // Count the number of lines in the output file.
    print_num_lines(outputFile);

    return 0;
}
