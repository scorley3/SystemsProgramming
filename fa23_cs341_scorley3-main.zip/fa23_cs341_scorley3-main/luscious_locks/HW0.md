# Welcome to Homework 0!

For these questions you'll need the mini course and  "Linux-In-TheBrowser" virtual machine (yes it really does run in a web page using javascript) at -

http://cs-education.github.io/sys/

Let's take a look at some C code (with apologies to a well known song)-
```C
// An array to hold the following bytes. "q" will hold the address of where those bytes are.
// The [] mean set aside some space and copy these bytes into teh array array
char q[] = "Do you wanna build a C99 program?";

// This will be fun if our code has the word 'or' in later...
#define or "go debugging with gdb?"

// sizeof is not the same as strlen. You need to know how to use these correctly, including why you probably want strlen+1

static unsigned int i = sizeof(or) != strlen(or);

// Reading backwards, ptr is a pointer to a character. (It holds the address of the first byte of that string constant)
char* ptr = "lathe"; 

// Print something out
size_t come = fprintf(stdout,"%s door", ptr+2);

// Challenge: Why is the value of away equal to 1?
int away = ! (int) * "";


// Some system programming - ask for some virtual memory

int* shared = mmap(NULL, sizeof(int*), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
munmap(shared,sizeof(int*));

// Now clone our process and run other programs
if(!fork()) { execlp("man","man","-3","ftell", (char*)0); perror("failed"); }
if(!fork()) { execlp("make","make", "snowman", (char*)0); execlp("make","make", (char*)0)); }

// Let's get out of it?
exit(0);
```

## So you want to master System Programming? And get a better grade than B?
```C
int main(int argc, char** argv) {
	puts("Great! We have plenty of useful resources for you, but it's up to you to");
	puts(" be an active learner and learn how to solve problems and debug code.");
	puts("Bring your near-completed answers the problems below");
	puts(" to the first lab to show that you've been working on this.");
	printf("A few \"don't knows\" or \"unsure\" is fine for lab 1.\n"); 
	puts("Warning: you and your peers will work hard in this class.");
	puts("This is not CS225; you will be pushed much harder to");
	puts(" work things out on your own.");
	fprintf(stdout,"This homework is a stepping stone to all future assignments.\n");
	char p[] = "So, you will want to clear up any confusions or misconceptions.\n";
	write(1, p, strlen(p) );
	char buffer[1024];
	sprintf(buffer,"For grading purposes, this homework 0 will be graded as part of your lab %d work.\n", 1);
	write(1, buffer, strlen(buffer));
	printf("Press Return to continue\n");
	read(0, buffer, sizeof(buffer));
	return 0;
}
```
## Watch the videos and write up your answers to the following questions

**Important!**

The virtual machine-in-your-browser and the videos you need for HW0 are here:

http://cs-education.github.io/sys/

The coursebook:

http://cs341.cs.illinois.edu/coursebook/index.html

Questions? Comments? Use Ed: (you'll need to accept the sign up link I sent you)
https://edstem.org/

The in-browser virtual machine runs entirely in Javascript and is fastest in Chrome. Note the VM and any code you write is reset when you reload the page, *so copy your code to a separate document.* The post-video challenges (e.g. Haiku poem) are not part of homework 0 but you learn the most by doing (rather than just passively watching) - so we suggest you have some fun with each end-of-video challenge.

HW0 questions are below. Copy your answers into a text document (which the course staff will grade later) because you'll need to submit them later in the course. More information will be in the first lab.

## Chapter 1

In which our intrepid hero battles standard out, standard error, file descriptors and writing to files.

### Hello, World! (system call style)
1. Write a program that uses `write()` to print out "Hi! My name is `<Your Name>`".
```C
#include <unistd.h>
int main() {
	write(STDOUT_FILENO, "Hi! My name is Sam", 18);
	return 0;
}
```

### Hello, Standard Error Stream!
2. Write a function to print out a triangle of height `n` to standard error.
   - Your function should have the signature `void write_triangle(int n)` and should use `write()`.
   - The triangle should look like this, for n = 3:
   ```C
   *
   **
   ***
```

void write_triangle(int n) {
	int stars;
	int s;
	for (stars = 1; stars <= n; stars++) {
		for (s = 0; s < stars; s++) {
			write(STDOUT_FILENO, "*", 1);
		}
		write(STDOUT_FILENO, "\n", 1);
	}
	
}
```
### Writing to files
3. Take your program from "Hello, World!" modify it write to a file called `hello_world.txt`.
   - Make sure to to use correct flags and a correct mode for `open()` (`man 2 open` is your friend).
```C
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
int main() {
	int filedes = open("hello_world.txt", O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR); 
	write(filedes, "Hi! My name is Sam", 18);
	close(filedes);
	return 0;
}
```

### Not everything is a system call
4. Take your program from "Writing to files" and replace `write()` with `printf()`.
   - Make sure to print to the file instead of standard out!
```C
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
int main() {
	close(1);
	int filedes = open("hello_world.txt", O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR); 
	printf("Hi! My name is Sam\n");
	close(filedes);
	return 0;
}
```

5. What are some differences between `write()` and `printf()`?
write() is a system call, whereas printf() is a C standard library function that wraps a system call to write(). write() takes parameters for where to write and how many bytes to write, whereas printf automatically prints to file descriptor 1 and doesn't require specification of the number of bytes to write. 
## Chapter 2

Sizing up C types and their limits, `int` and `char` arrays, and incrementing pointers

### Not all bytes are 8 bits?
1. How many bits are there in a byte?
At least 8 but possibly more. On my machine, there are 8 bits in a byte.
2. How many bytes are there in a `char`?
There is 1 byte in a 'char'.
3. How many bytes the following are on your machine?
   - `int`, `double`, `float`, `long`, and `long long`

int is 4 bytes, double is 8 bytes, float is 4 bytes, long is 8 bytes, and long long is 8 bytes. 

### Follow the int pointer
4. On a machine with 8 byte integers:
```C
int main(){
    int data[8];
} 
```
If the address of data is `0x7fbd9d40`, then what is the address of `data+2`?

0x7fbd9d50

5. What is `data[3]` equivalent to in C?
   - Hint: what does C convert `data[3]` to before dereferencing the address?
data + 3 

### `sizeof` character arrays, incrementing pointers
  
Remember, the type of a string constant `"abc"` is an array.

6. Why does this segfault?
```C
char *ptr = "hello";
*ptr = 'J';
```
String literals as stored in the text/code area of the address space, which is immutable. This means that we are not allowed to write to the memory of a string literal. 

7. What does `sizeof("Hello\0World")` return?
12

8. What does `strlen("Hello\0World")` return?
5

9. Give an example of X such that `sizeof(X)` is 3.
char* X = "hi";

10. Give an example of Y such that `sizeof(Y)` might be 4 or 8 depending on the machine.
long Y = 10L;

## Chapter 3

Program arguments, environment variables, and working with character arrays (strings)

### Program arguments, `argc`, `argv`
1. What are two ways to find the length of `argv`?
argc tells us the length of argv, as argc is an integer representing the number of command-line arguments including the program name. Alternatively, we could find the length of argv by incrementing the pointer until we reach the NULL pointer and keeping count of the number of elements we find. 

2. What does `argv[0]` represent?
The name of the program. 

### Environment Variables
3. Where are the pointers to environment variables stored (on the stack, the heap, somewhere else)?
The pointers to environment variables are stored in an array of pointers to character strings. This array is stored separately from the stack and the heap and is above the stack in the address space.  

### String searching (strings are just char arrays)
4. On a machine where pointers are 8 bytes, and with the following code:
```C
char *ptr = "Hello";
char array[] = "Hello";
```
What are the values of `sizeof(ptr)` and `sizeof(array)`? Why?
sizeof(ptr) = 8 because we are evaluating the size of a pointer, and pointers are 8 bytes in this machine. sizeof(array) is 6 because we are evaluating the size of the char array, which is 5 bytes for "Hello" and 1 byte for the null terminator, which adds up to 6 bytes. 

### Lifetime of automatic variables

5. What data structure manages the lifetime of automatic variables?
The stack manages the lifetime of automatic variables.

## Chapter 4

Heap and stack memory, and working with structs

### Memory allocation using `malloc`, the heap, and time
1. If I want to use data after the lifetime of the function it was created in ends, where should I put it? How do I put it there?
You should put the data on the heap. In order to put data on the heap, you can call malloc (or calloc/realloc) with the number of bytes that you want to store. That data will live until free is called on it. Another option is to store data in the static memory, separate from the stack and the heap. That data will live for the entire lifetime of the program. 

2. What are the differences between heap and stack memory?
On the stack, memory management is automatic, and on the heap, memory management is manual. Data on the stack lives until the scope of its function ends, whereas data on the heap lives until it is explicitly deallocated. The stack is where function calls and local variables are stored, and the heap is used for dynamic memory allocation, that is, it is often used for data for which the size is not known at compile time (example: string). 

3. Are there other kinds of memory in a process?
There is also static memory, where static variables are stored, and the code/data segment, which is usually read-only. 

4. Fill in the blank: "In a good C program, for every malloc, there is a ___".
free 

### Heap allocation gotchas
5. What is one reason `malloc` can fail?
One reason that 'malloc' could fail is if it has already used up all of the heap memory. If 'malloc' fails, it will return the null pointer. 

6. What are some differences between `time()` and `ctime()`?
time() is a system call and ctime() is a C library function. time() returns the time as type time_t and ctime() returns a pointer to the string representing the time in ASCII. ctime() uses static storage; if it is called multiple times, it will overwrite the time currently stored.  

7. What is wrong with this code snippet?
```C
free(ptr);
free(ptr);
```
We are freeing memory that has already been freed. This is called a double free error. 

8. What is wrong with this code snippet?
```C
free(ptr);
printf("%s\n", ptr);
```
We are attempting to print from memory that has been deallocated. This is called a dangling pointer error.

9. How can one avoid the previous two mistakes? 
We can avoid these mistakes by setting pointers to 0/NULL when we deallocate their memory. 

### `struct`, `typedef`s, and a linked list
10. Create a `struct` that represents a `Person`. Then make a `typedef`, so that `struct Person` can be replaced with a single word. A person should contain the following information: their name (a string), their age (an integer), and a list of their friends (stored as a pointer to an array of pointers to `Person`s).
```C
struct Person {
	char* name;
	int age;
	Person** friends;
};

typedef struct Person person_t;
```
11. Now, make two persons on the heap, "Agent Smith" and "Sonny Moore", who are 128 and 256 years old respectively and are friends with each other.
```C
person_t* smith = (person_t*) malloc(sizeof(person_t));
person_t* moore = (person_t*) malloc(sizeof(person_t));
smith->name = "Agent Smith";
smith->age = 128;
smith->friends = malloc(sizeof(person_t*));
*(smith->friends) = moore;
moore->name = "Sonny Moore";
moore->age = 256;
moore->friends = malloc(sizeof(person_t*));
*(moore->friends) = smith;

free(smith);
free(moore);
smith = NULL;
moore = NULL;
```
### Duplicating strings, memory allocation and deallocation of structures
Create functions to create and destroy a Person (Person's and their names should live on the heap).

12. `create()` should take a name and age. The name should be copied onto the heap. Use malloc to reserve sufficient memory for everyone having up to ten friends. Be sure initialize all fields (why?).
```C
person_t* create(char* name, int age) {
	person_t* p = (person_t*) malloc(sizeof(person_t));
	p->age = age; 
	p->name = strdup(name);
	p->friends = (person_t**) malloc(sizeof(person_t*) * 10);

	int i; 
	for (i = 0; i < 10; i++) {
		p->friends[i] = NULL;
	}
	
	return p;
}
```
13. `destroy()` should free up not only the memory of the person struct, but also free all of its attributes that are stored on the heap. Destroying one person should not destroy any others.
```C
void destroy(person_t* p) {
	free(p->name);
	free(p->friends);
	memset(p, 0, sizeof(person_t));
	free(p);
}
```

## Chapter 5 

Text input and output and parsing using `getchar`, `gets`, and `getline`.

### Reading characters, trouble with gets
1. What functions can be used for getting characters from `stdin` and writing them to `stdout`?
getchar, getline, and gets can be used for reading from 'stdin', and getchar is the function used to get a single character at a time. putchar, printf, and puts can be used to write characters to 'stdout', and putchar is the function used to write a single char to 'stdout'. 

2. Name one issue with `gets()`.
gets()
If we input more data than will fit in the buffer, we can get buffer overflow and write to memory being used by another variable. 

### Introducing `sscanf` and friends
3. Write code that parses the string "Hello 5 World" and initializes 3 variables to "Hello", 5, and "World".
```C
char * data = "Hello 5 World"; 
char word1[6];
int number = 0;
char word2[6];
sscanf(data, "%s %d %s", word1, &number, word2);
```

### `getline` is useful
4. What does one need to define before including `getline()`?
We need to define GNU Source by writing '#define _GNU_SOURCE

5. Write a C program to print out the content of a file line-by-line using `getline()`.
```C
char *buffer = NULL; 
size_t capacity = 0; 
ssize_t charsRead = 0;

FILE *file; 
file = fopen("somefile.txt", "r");

while ((charsRead = getline(&buffer, &capacity, file)) != -1) {
	printf("%s", buffer);
}

fclose(file);
if (buffer) free(buffer);
```

## C Development

These are general tips for compiling and developing using a compiler and git. Some web searches will be useful here

1. What compiler flag is used to generate a debug build?
The -g flag is used to generate a debug build. 

2. You modify the Makefile to generate debug builds and type `make` again. Explain why this is insufficient to generate a new build.
The changes might not be recognized because the source files have not changed, only the compiler flags, and Make determines whether targets need to be rebuilt using a dependency-based approach. In order to generate a new build, you can run 'make clean' and then run 'make' again. 

3. Are tabs or spaces used to indent the commands after the rule in a Makefile?
Tabs are used to indent the commands, and Make may not interpret the Makefile correctly if you use spaces. 

4. What does `git commit` do? What's a `sha` in the context of git?
'git commit' gathers the changes you have made since your last commit and stores them in the Git database as a commit object with an SHA and a commit message. A 'sha' in the context of git refers to the unique cryptographic hash that is generated for each Git commit and all Git objects, and it ensures data integrity and uniqueness. 

5. What does `git log` show you?
git log shows you a detailed history of commits in a Git repository in reverse chronological order. Each log entry has the commit SHA, author/committer, date and time, and commit message. 

6. What does `git status` tell you and how would the contents of `.gitignore` change its output?
'git status' gives us info about the current state of the working directory and commit staging area in relation to your Git repository. It tells you the changes to be committed, changes not staged for commit, and untracked files. The '.gitignore' file specifies patterns of files/directories that Git should ignore when determining repository status. Thus, ignored files and directories won't appear in the "Untracked Files" section of the output of 'git status'. 

7. What does `git push` do? Why is it not just sufficient to commit with `git commit -m 'fixed all bugs' `?
'git push' uploads local commits and changes to a remote repository. 'git commit' records your changes locally, but it is not sufficient because we need to use 'git push' in order to share changes with others or sync them with a remote. 

8. What does a non-fast-forward error `git push` reject mean? What is the most common way of dealing with this?
This error usually means that there are commits in the remote repository that do not exist in your local branch. The most common way to deal with the error is to fetch the latest changes from the remote and merge/rebase local changes on top of the updated local branch. Then, the push should succeed. 

## Optional (Just for fun)
- Convert your a song lyrics into System Programming and C code and share on Ed.
- Find, in your opinion, the best and worst C code on the web and post the link to Ed.
- Write a short C program with a deliberate subtle C bug and post it on Ed to see if others can spot your bug.
- Do you have any cool/disastrous system programming bugs you've heard about? Feel free to share with your peers and the course staff on Ed.
