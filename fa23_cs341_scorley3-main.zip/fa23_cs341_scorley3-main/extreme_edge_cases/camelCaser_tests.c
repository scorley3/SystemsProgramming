/**
 * extreme_edge_cases
 * CS 341 - Fall 2023
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "camelCaser.h"
#include "camelCaser_tests.h"

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

int check_output(char **test, char* testCorrect[]) {
    if (test == NULL && testCorrect == NULL) return 1;
    if (*test == NULL && testCorrect == NULL) return 1;

    int i = 0;    
    while (*test && testCorrect[i]) {
	DEBUG_PRINT("%s and %s\n", *test, testCorrect[i]);
	if (strcmp(testCorrect[i], *test) != 0) {
	    return 0;
	}
	i++;
	test++;
    }
    if (*test) return 0;
    if (*(testCorrect + i)) return 0;
    return 1;
}
int test_camelCaser(char **(*camelCaser)(const char *),
                    void (*destroy)(char **)) {
    // TODO: Implement me!
    if (!check_output(NULL, NULL)) return 0;

    char *word0 = "hello";
    char **test0 = camelCaser(word0);

    if (!check_output(test0, NULL)) return 0; 

    char *word1 = "     hello.     "; 
    char *test1Correct[] = {"hello", NULL};
    char **test1 = camelCaser(word1);
    
    if (!check_output(test1, test1Correct)) return 0;

    char *word2 = "hello darkness my old friend.";
    char *test2Correct[] = {"helloDarknessMyOldFriend", NULL};
    char **test2 = camelCaser(word2);
    
    if (!check_output(test2, test2Correct)) return 0;
    
    char *word3 = "hello everyone. WELCOME TO THE SHOW.";
    char *test3Correct[] = {"helloEveryone", "welcomeToTheShow", NULL};
    char **test3 = camelCaser(word3);

    if (!check_output(test3, test3Correct)) return 0;

    char *word4 = "hello everyone. Welcome to the show";
    char *test4Correct[] = {"helloEveryone", NULL};
    char **test4 = camelCaser(word4);

    if (!check_output(test4, test4Correct)) return 0;

    char *word5 = "oOhHhhHHhh! TaKe A RiD3 On the wild side!";
    char *test5Correct[] = {"oohhhhhhhh", "takeARid3OnTheWildSide", NULL};
    char **test5 = camelCaser(word5);
    
    if (!check_output(test5, test5Correct)) return 0;

    char *word6 = "hello     !     i am sam .WILL THIS TEST PASS? .    .";
    char *test6Correct[] = {"hello", "iAmSam", "willThisTestPass", "", "", NULL};
    char **test6 = camelCaser(word6);

    if (!check_output(test6, test6Correct)) return 0;

    char *word7 = "...12,2341,12";
    char *test7Correct[] = {"", "", "", "12","2341", NULL};
    char **test7 = camelCaser(word7);

    if (!check_output(test7, test7Correct)) return 0;
    
    char *word8 = "hey_mY!NAM3333 is 5sam;";
    char *test8Correct[] = {"hey", "my", "nam3333Is5Sam", NULL};
    char **test8 = camelCaser(word8);

    if (!check_output(test8, test8Correct)) return 0;

    destroy(test0);
    destroy(test1);
    destroy(test2);
    destroy(test3);
    destroy(test4);
    destroy(test5);
    destroy(test6);
    destroy(test7);
    destroy(test8);

    return 1;
}
