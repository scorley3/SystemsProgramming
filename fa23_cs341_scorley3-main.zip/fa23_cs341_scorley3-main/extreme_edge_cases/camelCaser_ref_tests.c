/**
 * extreme_edge_cases
 * CS 341 - Fall 2023
 */
#include <stdio.h>

#include "camelCaser_ref_utils.h"

int main() {
    // Enter the string you want to test with the reference here.
    char *input = "hello. welcome to cs241";

    // This function prints the reference implementation output on the terminal.
    print_camelCaser(input);

    // Put your expected output for the given input above.
    char *correct[] = {"hello", NULL};
    // char *wrong[] = {"hello", "welcomeToCs241", NULL};

    // Compares the expected output you supplied with the reference output.
    printf("check_output test 1: %d\n", check_output(input, correct));
    //printf("check_output test 2: %d\n", check_output(input, wrong));

    char *word5 = "oOhHhhHHhh! TaKe A RiD3 On the wild side!";
    char *test5Correct[] = {"oohhhhhhhh", "takeARid3OnTheWildSide", NULL};

    printf("sanity check: %d \n:",check_output(word5, test5Correct));
    // Feel free to add more test cases.


    print_camelCaser("hey_mY!NAM3333 is 5sam;");
    // Feel free to add more test cases.
    return 0;
}
