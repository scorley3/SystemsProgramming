/**
 * extreme_edge_cases
 * CS 341 - Fall 2023
 */
#include "camelCaser.h"
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

char **camel_caser(const char *input_str) {
    if (!input_str) return NULL;

    char **result = malloc(sizeof(char*) * 2);
    result[1] = NULL;
    char ** temp = result;
    long result_capacity = 1;
	
    char *word = calloc(2, 1); 
    char *current = word;
    long current_capacity = 1;

    int makeCapital = 0;

    while (*input_str) {
	if (isspace(*input_str)) {
	    if (*word) {
	       makeCapital = 1;
	    }
	}
	else if (ispunct(*input_str)) {
	    DEBUG_PRINT("deal punct %c --> store word %s\n", *input_str, word);

	    *temp = word;
	    temp++;
	    *current = '\0';
	    word = calloc(2, 1); 
	    current = word;
	    current_capacity = 1;
	    makeCapital = 0;

	    if (temp - result == result_capacity) {
		DEBUG_PRINT("extending result to %lu\n", result_capacity * 2);
		result = realloc(result, sizeof(char*) * result_capacity * 2);
		temp = result + result_capacity; 
		result_capacity *= 2;
	    }
	}
	else {
	    if (makeCapital) {
		*current = toupper(*input_str);
	    	if (isalpha(*current)) makeCapital = 0;
	    }
	    else {
		*current = tolower(*input_str);
	    }
	    current++;
	    if (current - word == current_capacity) {
		DEBUG_PRINT("extending word to %lu\n", current_capacity * 2);
		word = realloc(word, current_capacity * 2);
		current = word + current_capacity; 
		current_capacity *= 2;
	    }

	    DEBUG_PRINT("dealt with and character %c --> word is now %s\n", *input_str, word);
	}
	input_str++;
    }
    *current = '\0';
    *temp = NULL;
    if (word) free(word);
    return result;
}

void destroy(char **result) {
    char ** temp = result;
    while (*temp) {
	char *word = *temp; 
	free(word);
	temp++;
    }
    free(result);
    return;
}
