/**
 * finding_filesystems
 * CS 341 - Fall 2023
 */
#include "minixfs.h"
#include "minixfs_utils.h"
#include <assert.h>

int main(int argc, char *argv[]) {
    // Write tests here!

    // test of read
    // read with offset + count longer than file
    // multiple reads
    // write to file
    //
}
