/**
 * finding_filesystems
 * CS 341 - Fall 2023
 */
#include "minixfs.h"
#include "minixfs_utils.h"
#include <asm-generic/errno-base.h>
#include <bits/time.h>
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

/**
 * Virtual paths:
 *  Add your new virtual endpoint to minixfs_virtual_path_names
 */
char *minixfs_virtual_path_names[] = {"info", /* add your paths here*/};

/**
 * Forward declaring block_info_string so that we can attach unused on it
 * This prevents a compiler warning if you haven't used it yet.
 *
 * This function generates the info string that the virtual endpoint info should
 * emit when read
 */
static char *block_info_string(ssize_t num_used_blocks) __attribute__((unused));
static char *block_info_string(ssize_t num_used_blocks) {
    char *block_string = NULL;
    ssize_t curr_free_blocks = DATA_NUMBER - num_used_blocks;
    asprintf(&block_string,
             "Free blocks: %zd\n"
             "Used blocks: %zd\n",
             curr_free_blocks, num_used_blocks);
    return block_string;
}

// Don't modify this line unless you know what you're doing
int minixfs_virtual_path_count =
    sizeof(minixfs_virtual_path_names) / sizeof(minixfs_virtual_path_names[0]);

// return 0 on success and -1 on failure
int minixfs_chmod(file_system *fs, char *path, int new_permissions) {
    // Thar she blows!
    // need to deal with permissions
    inode *node = get_inode(fs, path);
    if (!node) {
        if (access(path, F_OK) == -1) {
            errno = ENOENT;
        }
        return -1;
    }
    uint16_t mode = node->mode;
    int newMode = (mode >> RWX_BITS_NUMBER) << RWX_BITS_NUMBER;
    node->mode = new_permissions | newMode;

    if (clock_gettime(CLOCK_REALTIME, &node->ctim) == 0) {
        return 0;
    }
    return -1;
}

// returns -1 on fail and 0 on success
int minixfs_chown(file_system *fs, char *path, uid_t owner, gid_t group) {
    // Land ahoy!
    inode *node = get_inode(fs, path);
    if (!node) {
        if (access(path, F_OK) == -1) {
            errno = ENOENT;
        }
        return -1;
    }

    if (owner != (uid_t) -1) {
        node->uid = owner;
    }

    if (group != (gid_t) -1) {
        node->gid = group;
    }

    if (clock_gettime(CLOCK_REALTIME, &node->ctim) == 0) {
        return 0;
    }
    return -1;
}

inode *minixfs_create_inode_for_path(file_system *fs, const char *path) {
    // Land ahoy!
    // need to write dirent

    inode *node = NULL;
    if ((node = get_inode(fs, path)) != NULL) {
        return NULL;
    }
    const char *fileName;
    node = parent_directory(fs, path, &fileName);
    if (!valid_filename(fileName)) {
        return NULL;
    }

    // how many data blocks have we used
    data_block_number used_blocks = node->size / sizeof(data_block);

    // if we have used all of the direct blocks and don't yet have an indirect block
    if (used_blocks >= NUM_DIRECT_BLOCKS && node->indirect == UNASSIGNED_NODE) {
        // try to add an indirect block to the inode
        inode_number status = add_single_indirect_block(fs, node);
        // if it doesn't work, return null
        if (status == -1) return NULL;
    }

    // get the index of the first unused inode
    inode_number num = first_unused_inode(fs);
    if (num == -1) {
        // no more inodes left that we can use
        return NULL;
    }

    // otherwise num is the index
    init_inode(node, fs->inode_root + num);

    data_block *dataBlockToUse = NULL;

    // check if all the data blocks in use are full
    if (node->size % sizeof(data_block) == 0) {
        // assign node to direct or indirect block
        data_block_number newBlockNum;

        if (node->indirect == UNASSIGNED_NODE){
            // means that we have direct blocks that aren't yet full
            newBlockNum = add_data_block_to_inode(fs, node);
        }
        else {
            // we need to add it to an indirect block
            // casting from data block * to data block number *
            data_block_number *num_indirects = (data_block_number *) fs->data_root + node->indirect;
            newBlockNum = add_data_block_to_indirect_block(fs, num_indirects);
        }

        if (newBlockNum == -1) {
            // we tried to add a new block but there aren't any left
            return NULL;
        }
        dataBlockToUse = fs->data_root + newBlockNum;
    }
    else {
        // we can use an existing data block
        if (node->indirect == UNASSIGNED_NODE) {
            // if we have direct blocks left
            // set data block to be the last used block that isn't full
            dataBlockToUse = fs->data_root + node->direct[used_blocks];

        }
        else {
            // if we need to use an indirect block
            // get "array" of indirect blocks
            data_block_number *num_indirects = (data_block_number *) fs->data_root + node->indirect;
            // get block that is in indirect blocks at total # - num of direct
            dataBlockToUse = fs->data_root + num_indirects[used_blocks - NUM_DIRECT_BLOCKS];
        }


    }

    minixfs_dirent dirent;
    dirent.inode_num = num;
    //strcpy(dirent.name, fileName);
    dirent.name = (char *) fileName;
    make_dirent_from_string((char *) dataBlockToUse, &dirent);

    node->size += FILE_NAME_ENTRY;
    // return inode root + index of first previously unused inode
    return fs->inode_root + num;


    return NULL;
}

ssize_t minixfs_virtual_read(file_system *fs, const char *path, void *buf,
                             size_t count, off_t *off) {
    //printf("this is info %s \n", path);
    if (!strcmp(path, "info")) {
        //printf("path %s and /info \n", path);
        // TODO implement the "info" virtual file here
        //
        // need to create the string of
        //
        char *sb = GET_DATA_MAP(fs->meta);
        ssize_t usedBlocks = 0;
        uint64_t blocksTotal = fs->meta->dblock_count;
        for (uint64_t blockNum = 0; blockNum < blocksTotal; blockNum++) {
            if (sb[blockNum] == 1) {
                usedBlocks++;
            }
        }

        char *string = block_info_string(usedBlocks);
        // printf("%s \n", string);

        if ((size_t)(*off) >= strlen(string)) {
            return 0;
        }

        if ((size_t)(*off + count) > strlen(string)) {
            count = strlen(string) - *off;
        }

        strncpy(buf, string + *off, count);
        *off += count;
        //free(string);
        //printf("this will print when we finish the function %lu \n", count);
        //
        return count;
    }

    errno = ENOENT;
    return -1;
}

// need to add blocks to write
ssize_t minixfs_write(file_system *fs, const char *path, const void *buf,
                      size_t count, off_t *off) {

    // if the offset is > than the number of blocks, return -1
    if ((unsigned long) *off > (NUM_DIRECT_BLOCKS + NUM_INDIRECT_BLOCKS) * sizeof(data_block)) {
        errno = ENOSPC;
        return -1;
    }

    // X marks the spot
    inode *node = get_inode(fs, path);
    if (!node) {
        node = minixfs_create_inode_for_path(fs, path);
    }

    uint64_t offset = *off;
    if (offset >= node->size) {
        return 0;
    }

    size_t blocksNeeded = (*off + count) / sizeof(data_block);
    if ((*off + count) % sizeof(data_block)) blocksNeeded++;

    // if we don't have enough blocks left FAILLLL
    if (minixfs_min_blockcount(fs, path, blocksNeeded) == -1) {
        errno = ENOSPC;
        return -1;
    }

    // how many blocks to skip over
    size_t numBlocks = offset / sizeof(data_block);
    // if there is a data block partially filled
    size_t blockOffset = offset % sizeof(data_block);

    // if numBlocks is more than the number of direct blocks and we have no assigned indirect bloc
    if (numBlocks >= NUM_DIRECT_BLOCKS && node->indirect == UNASSIGNED_NODE) {
        // try to add an indirect block to the inode
        inode_number status = add_single_indirect_block(fs, node);
        // if it doesn't work, return null
        if (status == -1) return -1;
    }

    // endingByte is the last byte that we want to write
    off_t endingByte = *off + count;

    size_t bytes = 0;

    while (*off < endingByte) {
        // if we have gone past the last block, we are done
        if (numBlocks >= NUM_DIRECT_BLOCKS + NUM_INDIRECT_BLOCKS) {
            node->size += bytes;
            return bytes;
        }
        data_block blockToRead;

       // if (blockOffset) {
         //   if (node->indirect == UNASSIGNED_NODE) {
          //                  }
        //}
        if (numBlocks < NUM_DIRECT_BLOCKS) {
            blockToRead = fs->data_root[node->direct[numBlocks]];
        }
        else {
            data_block_number *indirect = (data_block_number *)fs->data_root + node->indirect;
            blockToRead = fs->data_root[indirect[numBlocks - NUM_DIRECT_BLOCKS]];
        }

        size_t toWrite = sizeof(data_block) - blockOffset;

        if ((size_t)(endingByte - *off) < toWrite) toWrite = endingByte - *off;

        memcpy(blockToRead.data, buf + toWrite, toWrite);

        *off += toWrite;
        bytes += toWrite;
        numBlocks++;
        blockOffset = 0;
    }
    clock_gettime(CLOCK_REALTIME, &node->mtim);
    clock_gettime(CLOCK_REALTIME, &node->atim);
    node->size += bytes;
    return bytes;
}

ssize_t minixfs_read(file_system *fs, const char *path, void *buf, size_t count,
                     off_t *off) {
    const char *virtual_path = is_virtual_path(path);
    if (virtual_path) {
        //printf("this prints every time we enter this %s\n", virtual_path);
        return minixfs_virtual_read(fs, virtual_path, buf, count, off);
    }

    inode *node = get_inode(fs, path);
    if (!node) {
        errno = ENOENT;
        return -1;
    }

    uint64_t offset = *off;
    if (offset >= node->size) {
        // offset is more than the size so don't need to read anything
        return 0;
    }

    size_t numBlocks = offset / sizeof(data_block);
    size_t blockOffset = offset % sizeof(data_block);

    off_t endingByte;
    if (count + offset >= node->size) endingByte = node->size;
    else endingByte = count + offset;

    size_t bytes = 0;
    while (*off < endingByte) {
        data_block blockToRead;
        if (numBlocks < NUM_DIRECT_BLOCKS) {
            blockToRead = fs->data_root[node->direct[numBlocks]];
        }
        else {
            data_block_number *indirect = (data_block_number *)fs->data_root + node->indirect;
            blockToRead = fs->data_root[indirect[numBlocks - NUM_DIRECT_BLOCKS]];
        }

        size_t toRead = sizeof(data_block) + blockOffset;
        if ((size_t)(endingByte - *off) < toRead) toRead = endingByte - *off;

        memcpy(buf + bytes, blockToRead.data, toRead);

        *off += toRead;
        bytes += toRead;


        numBlocks++; // moves us to next block
        blockOffset = 0; // puts us at the start of the next block (no offset)

    }

    *off = endingByte;
    clock_gettime(CLOCK_REALTIME, &node->atim);
    return bytes;
}
