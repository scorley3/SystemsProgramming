/**
 * shell
 * CS 341 - Fall 2023
 */
#include "format.h"
#include "shell.h"
#include "includes/sstring.h"
#include "includes/vector.h"
#include <bits/getopt_core.h>
#include <complex.h>
#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

static char *directory;
static vector *backgroundProc;
static vector *commandHistory;
static int historyFileSize;
static bool history;
static FILE *historyFile;
static FILE *stream;


typedef struct process {
    char *command;
    pid_t pid;




} process;

void *copyProcess(void *p) {
    process * ptr = (process *)(p);
    process *this = malloc(sizeof(process));
    this->command = malloc(strlen(ptr->command) + 1);
    strcpy(this->command, ptr->command);
    this->pid = ptr->pid;
    return this;
}

void *defaultProcess() {
    process *this = malloc(sizeof(process));
    this->command = "";
    this->pid = 0;
    return this;
}

void destructProcess(void *p) {
    process *ptr = (process *)(p);
    free(ptr->command);
    free(ptr);
}

void addToHistory(char * command) {
    vector_push_back(commandHistory, command);
}

void catchInterrupt() {
    return;
}

int changeDir(char * path) {
    if (chdir(path) != 0) {
        print_no_directory(path);
        return 1;
    }
    directory = getcwd(directory, 100);
    return 0;
}

void doExit(int status) {
    if (history) {
        size_t i;
        for (i = historyFileSize; i < vector_size(commandHistory); i++) {
            fprintf(historyFile, "%s\n", (char *)(vector_get(commandHistory, i)));
            fflush(historyFile);
        }
        fclose(historyFile);
    }
    if (!vector_empty(backgroundProc)) {
        size_t i;
        for (i = 0; i < vector_size(backgroundProc); i++) {
            process *proc = vector_get(backgroundProc, i);
            kill(proc->pid, SIGKILL);
        }
    }
    fclose(stream);
    exit(status);
}

void processFile(char *file) {
    stream = fopen(file, "r");
    if (!stream) {
        print_script_file_error();
        doExit(1);
    }
}

void setHistory(char *file) {
    char * command = NULL;
    int bytes = 0;
    size_t buffer_size = 0;
    historyFile = fopen(file, "a+");

    if (!historyFile) {
        print_history_file_error();
        doExit(1);
    }

    while ((bytes = getline(&command, &buffer_size, historyFile)) != -1) {
        command[bytes - 1] = '\0';
        vector_push_back(commandHistory, command);

    }

    historyFileSize = vector_size(commandHistory);
    history = true;
}

void doOptions(int argc, char *argv[]) {
    int o;
    while ((o = getopt(argc, argv, "h:f:")) != -1) {
        switch (o) {
            case 'h':
                setHistory(optarg);
                break;
            case 'f':
                processFile(optarg);
                break;
        };
    }
}

void showHistory() {
    if (vector_empty(commandHistory)) {
        return;
    }

    size_t i;
    for (i = 0; i < vector_size(commandHistory); i++) {
        print_history_line(i, (char *) (vector_get(commandHistory, i)));
    }
}

int doSignal(char *input) {
    vector * args = sstring_split(cstr_to_sstring(input), ' ');
    char *command = (char *)(vector_get(args, 0));

    if (strcmp(command, "kill") == 0) {
        addToHistory(input);
        if (vector_size(args) == 1) {
            print_invalid_command(input);
        }
        else {
            int pid = atoi((char *)(vector_get(args, 1)));
            size_t i;
            for (i = 0; i < vector_size(backgroundProc); i++) {
                process *proc = vector_get(backgroundProc, i);
                if (proc->pid == pid) {
                    DEBUG_PRINT("found process to kill %d \n", pid);
                    kill(pid, SIGKILL);
                    print_killed_process(pid, proc->command);
                    vector_erase(backgroundProc, i);
                    return 1;
                }
            }

            print_no_process_found(pid);
        }
        return 1;

    }
    else if (strcmp(command, "stop") == 0) {
        addToHistory(input);
        if (vector_size(args) == 1) {
            print_invalid_command(input);
        }
        else {
            int pid = atoi((char *)(vector_get(args, 1)));
            size_t i;
            for (i = 0; i < vector_size(backgroundProc); i++) {
                process *proc = vector_get(backgroundProc, i);
                if (proc->pid == pid) {
                    kill(pid, SIGSTOP);
                    print_stopped_process(pid, proc->command);
                    return 1;
                }
            }
            print_no_process_found(pid);
        }
        return 1;

    }
    else if (strcmp(command, "cont") == 0) {
        addToHistory(input);
        if (vector_size(args) == 1) {
            print_invalid_command(input);
        }
        else {
            int pid = atoi((char *)(vector_get(args, 1)));
            size_t i;
            for (i = 0; i < vector_size(backgroundProc); i++) {
                process *proc = vector_get(backgroundProc, i);
                if (proc->pid == pid) {
                    kill(pid, SIGCONT);
                    print_continued_process(pid, proc->command);
                    return 1;
                }
            }
            print_no_process_found(pid);
        }
        return 1;
    }
    return 0;

}

char *read_field_from_file(const char *filename, int field_number) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
    }

    char *field = NULL;
    size_t len = 0;
    ssize_t read;

    char *nextSpace = NULL;

    if ((read = getline(&field, &len, file)) != -1) {
        DEBUG_PRINT("%s \n", field);

        if (field_number == 1) {
            nextSpace = strchr(field, ' ');
            *nextSpace = '\0';
            return field;
        }
        field_number--;
        while ((field = strchr(field, ' ')) != NULL) {
            if (field_number == 1) {
                nextSpace = strchr(field + 1, ' ');
                if (nextSpace) {
                    *nextSpace = '\0';
                }
                fclose(file);
                return field + 1;
            }
            field_number--;
            field += 1;
        }
    }

    return NULL;
}

clock_t read_btime() {
    FILE *file = fopen("/proc/stat", "r");
    if (file == NULL) {
        perror("Error opening /proc/stat");
        return 0;
    }

    char line[256];
    clock_t btime = 0;

    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "btime", 5) == 0) {
            char *btime_str = strchr(line, ' ') + 1; // Skip the space
            btime = atol(btime_str);
            break;
        }
    }

    fclose(file);

    return btime;

}

process_info *read_process_info(int pid) {
    process_info *info = malloc(sizeof(process_info));
    clock_t btime = read_btime();

    info->pid = pid;

    char proc_path[256];

    snprintf(proc_path, sizeof(proc_path), "/proc/%d/stat", pid);

    char status = *read_field_from_file(proc_path, 3);
    char *numThreads = read_field_from_file(proc_path, 20);
    char *vsize = read_field_from_file(proc_path, 23);
    char *starttime = read_field_from_file(proc_path, 22); // get 22nd line
    // char *cutime = read_field_from_file(proc_path, 9);
    // char *cstime = read_field_from_file(proc_path, 10);
    char *utime = read_field_from_file(proc_path, 14);
    char *stime = read_field_from_file(proc_path, 15);

    clock_t time = (btime + atoi(starttime)) / sysconf(_SC_CLK_TCK);

    struct tm *result_tm = malloc(sizeof(struct tm));
    localtime_r(&time, result_tm);

    char *timeStr = malloc(10);

    clock_t execTime = atoi(utime) + atoi(stime) /*+ atoi(cutime) + atoi(cstime)*/;
    double totalSeconds = (double)(execTime) / sysconf(_SC_CLK_TCK);
    int minutes = (double)(totalSeconds) / 60;
    int seconds = totalSeconds - (minutes * 60);
    DEBUG_PRINT("%s utime and %s stime", utime, stime);


    char *execStr = malloc(10);

    execution_time_to_string(execStr, 10, minutes, seconds);
    time_struct_to_string(timeStr, 10, result_tm);

    free(result_tm);

    info->start_str = timeStr;
    info->time_str = execStr;
    info->nthreads = atoi(numThreads);
    info->vsize = atoi(vsize) / 1024.0;

    info->state = status;

    return info;
}

void printPs() {
    print_process_info_header();

    process_info *info = read_process_info(getpid());
    info->command = "./shell";

    print_process_info(info);
    free(info->start_str);
    free(info->time_str);
    free(info);

    size_t index = 0;

    for (; index < vector_size(backgroundProc); index++) {
        process *proc = vector_get(backgroundProc, index);
        process_info *info = read_process_info(proc->pid);

        info->command = proc->command;


        print_process_info(info);
        free(info->start_str);
        free(info->time_str);
        free(info);
    }
}

int doCommandSimpleStream(char *input, int fileNo) {
    vector * args = sstring_split(cstr_to_sstring(input), ' ');
    char * command = (char *) vector_get(args, 0);

    if (strcmp(command, "cd") == 0) {
        return changeDir((char *)(vector_get(args, 1)));
    }
    else {
        fflush(NULL);
        fflush(stream);

        int original_out = dup(STDOUT_FILENO);

        pid_t pid = fork();

        if (pid == 0) {
            print_command_executed(getpid());

            dup2(fileNo, STDOUT_FILENO);

            char **execArgv = malloc(vector_size(args) * sizeof(char *));
            size_t i;
            for (i = 0; i < vector_size(args); i++) {
                execArgv[i] = (char *)(vector_get(args, i));
            }
            execvp(command, execArgv);
            free(execArgv);
            exit(1);
        }
        else if (pid > 0) {
            dup2(original_out, STDOUT_FILENO);
            int status;
            waitpid(pid, &status, 0);
            if (WEXITSTATUS(status)) {
                print_exec_failed(input);
                return 1;
            }
        }
        else {
            print_fork_failed();
            doExit(1);
        }
    }
    return 0;

}

int doCommandSimple(char *input) {
    return doCommandSimpleStream(input, STDOUT_FILENO);
}

int doCommandLogical(char operator, char *first, char *second) {
    int status = doCommandSimple(first);

    if (operator == '|') {
        if (status) {
            doCommandSimple(second);
        }
    }
    else if (operator == '&') {
        if (!status) {
            doCommandSimple(second);
        }
    }
    else if (operator == ';') {
        doCommandSimple(second);
    }
    return 1;

}

int doLogic(char *input) {
    char * secondCommand = NULL;

    if ((secondCommand = strstr(input, ";")) != NULL) {
        addToHistory(input);
        *secondCommand = '\0';
        secondCommand += 2;
        return doCommandLogical(';', input, secondCommand);
    }
    else if ((secondCommand = strstr(input, " &&")) != NULL) {
        addToHistory(input);
        *secondCommand = '\0';
        secondCommand += 4;
        return doCommandLogical('&', input, secondCommand);
    }
    else if ((secondCommand = strstr(input, " ||")) != NULL) {
        addToHistory(input);
        *secondCommand = '\0';
        secondCommand += 4;
        return doCommandLogical('|', input, secondCommand);
    }

    return 0;
}

int doRedirect(char *input) {
    char *redirect = NULL;

    if ((redirect = strstr(input, " >>")) != NULL) {
        addToHistory(input);
        *redirect = '\0'; // split string
        redirect += 4; // move past space

        FILE *file = fopen(redirect, "a");
        if (!file) {
            print_redirection_file_error();
            return 1;
        }

        doCommandSimpleStream(input, fileno(file));
        fclose(file);
        return 1;
    }
    else if ((redirect = strstr(input, " <")) != NULL) {
        addToHistory(input);
        *redirect = '\0'; // split string
        redirect += 3; // move past space

        int original_in = dup(STDIN_FILENO);

        FILE *file = fopen(redirect, "r");
        if (!file) {
            print_redirection_file_error();
            return 1;
        }

        dup2(fileno(file), STDIN_FILENO);
        doCommandSimple(input);
        dup2(original_in, STDIN_FILENO);
        fclose(file);
        return 1;

    }
    else if ((redirect = strstr(input, " >")) != NULL) {
        addToHistory(input);
        *redirect = '\0'; // split string
        redirect += 3; // move past space

        FILE *file = fopen(redirect, "w");
        if (!file) {
            print_redirection_file_error();
            return 1;
        }

        doCommandSimpleStream(input, fileno(file));
        fclose(file);
        return 1;
    }

    return 0;
}

int forkExec(char *line, vector *args) {
    pid_t pid = fork();
    if (pid == 0) {
        if (line[strlen(line) - 1] == '&') {
            line[strlen(line) - 2] = '\0';
            vector_erase(args, vector_size(args) - 1);
        }
        print_command_executed(getpid());
        char **execArgv = malloc(vector_size(args) * sizeof(char *));
        size_t i;
        for (i = 0; i < vector_size(args); i++) {
            execArgv[i] = (char *)(vector_get(args, i));
            DEBUG_PRINT("%s \n", execArgv[i]);
        }
        execvp((char *)(vector_get(args, 0)), execArgv);
        DEBUG_PRINT("this didn't work %s \n", line);
        free(execArgv);
        exit(1);
    }
    else if (pid > 0) {
        if (line[strlen(line) - 1] == '&') {
            process *process_entry = malloc(sizeof(process));
            process_entry->command = line;
            process_entry->pid = pid;
            vector_push_back(backgroundProc, process_entry);
            if (setpgid(pid, pid) == -1) {
                print_setpgid_failed();
            }
            DEBUG_PRINT("process added with pid: %d", pid);
            DEBUG_PRINT("actual pid: %d \n", process_entry->pid);
        }
        else {
            int status;
            waitpid(pid, &status, 0);

            if (WEXITSTATUS(status)) {
                print_exec_failed(line);
                return 1;
            }
        }
    }
    else {
        print_fork_failed();
        doExit(1);
    }
    return 0;
}


int doCommandHistory(char * line) {
    vector * args = sstring_split(cstr_to_sstring(line), ' ');
    char * command = (char *) vector_get(args, 0);
    print_command(line);

    DEBUG_PRINT("full line is: %s \n", line);
    DEBUG_PRINT("command is: %s \n", command);

    if (doLogic(line) || doRedirect(line) || doSignal(line)) {
        return 0;
    }
    else if (strcmp(command, "cd") == 0) {
        addToHistory(line);
        return changeDir((char *)(vector_get(args, 1)));
    }
    else if (strcmp(command, "!history") == 0) {
        showHistory();
    }
    else {
        addToHistory(line);
        fflush(NULL);
        fflush(stream);

        int status = forkExec(line, args);
        return status;
    }
    return 0;
}

int doHistory(size_t n) {
    if (n < vector_size(commandHistory) && n >= 0) {
        return doCommandHistory((char *)(vector_get(commandHistory, n)));
    }
    else {
        print_invalid_index();
        return 1;
    }
}

int doPrefix(char * prefix) {
    size_t length = strlen(prefix);
    int i;
    for (i = vector_size(commandHistory) - 1; i >= 0; i--) {
        char * command = vector_get(commandHistory, i);
        if (strncmp(prefix, command, length) == 0) {
            return doCommandHistory(command);
        }
    }
    print_no_history_match();
    return 1;
}

int doCommand(char * input) {
    vector *args = sstring_split(cstr_to_sstring(input), ' ');
    char * command = (char *) (vector_get(args, 0));
    DEBUG_PRINT("command to exec is: %s \n", command);

    if (strcmp(command, "exit") == 0) {
        DEBUG_PRINT("is it exiting %d \n", 1);
        doExit(0);
    }
    else if (strcmp(command, "cd") == 0) {
        changeDir(vector_get(args, 1));
        addToHistory(input);
    }
    else if (strcmp(command, "!history") == 0) {
        showHistory();
    }
    else if (strcmp(command, "ps") == 0) {
        printPs();
    }
    else if (command[0] == '#') {
        command++;
        char * end = NULL;
        long commandNum = strtol(command, &end, 10);
        DEBUG_PRINT("command number: %lu \n", commandNum);

        if (*end != '\0') {
            print_invalid_command(input);
            return 1;
        }
        else {
            doHistory(commandNum);
        }
    }
    else if (command[0] == '!') {
        doPrefix(command + 1);
    }
    else {
        addToHistory(input);
        fflush(NULL);
        fflush(stream);

        int status = forkExec(input, args);
        return status;
    }
    return 0;
}

void checkZombies() {
    size_t i;
    for(i = 0; i < vector_size(backgroundProc); i++) {

        process * proc = vector_get(backgroundProc, i);
        char proc_path[256];

        snprintf(proc_path, sizeof(proc_path), "/proc/%d/stat", proc->pid);
        char state = *read_field_from_file(proc_path, 3);

        if (state == 'Z') {
            kill(proc->pid, SIGKILL);
            vector_erase(backgroundProc, i);
        }
    }
}


int shell(int argc, char *argv[]) {
    if (argc % 2 != 1 || argc > 5) {
        print_usage();
        doExit(1);
    }

    stream = stdin;
    backgroundProc = vector_create(copyProcess, destructProcess, defaultProcess);
    commandHistory = string_vector_create();

    directory = malloc(100);
    getcwd(directory, 100);

    doOptions(argc, argv);

    char * input = NULL;
    int input_size = 0;
    size_t buffer_size = 0;
    signal(SIGINT, catchInterrupt);
    while (1) {
        print_prompt(directory, getpid());
        if ((input_size = getline(&input, &buffer_size, stream)) == -1) doExit(0);
        checkZombies();

        DEBUG_PRINT("input size: %d \n", input_size);

        if (input_size > 0) input[input_size - 1] = '\0';
        if (stream != stdin) print_command(input);

        DEBUG_PRINT("entire line is: %s \n", input);

        if (!doLogic(input) && !doRedirect(input) && !doSignal(input)) {
            doCommand(input);
        }
    }

    return 0;
}

