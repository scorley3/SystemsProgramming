/**
 * charming_chatroom
 * CS 341 - Fall 2023
 */
#pragma once

int my_read(int fd, void *buff, size_t count);