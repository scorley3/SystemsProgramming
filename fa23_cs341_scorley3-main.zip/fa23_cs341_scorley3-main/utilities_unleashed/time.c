/**
 * utilities_unleashed
 * CS 341 - Fall 2023
 */
#include <stdio.h>
#include "format.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        print_time_usage();
    }
    struct timespec *start_time = malloc(sizeof(struct timespec));
    clock_gettime(CLOCK_MONOTONIC, start_time);
    fflush(stdout);
    fflush(stderr);
    pid_t pid = fork();
    if (pid == 0) {
	execvp(argv[1], argv + 1);
	print_exec_failed();
	exit(1);
    }
    else if (pid > 0) {
	int status = 0;
	waitpid(pid, &status, 0);
	if (!WEXITSTATUS(status)) {
    	struct timespec *end_time = malloc(sizeof(struct timespec));
    	clock_gettime(CLOCK_MONOTONIC, end_time);
        double seconds = (double) (end_time->tv_sec - start_time->tv_sec);
	    display_results(argv, seconds + (double)(end_time->tv_nsec - start_time->tv_nsec) / 1000000000.0);
	    free(end_time);
	}
	else {
	    exit(1);
	}
    }
    else {
	print_fork_failed();
    }

    free(start_time);
    return 0;
}
