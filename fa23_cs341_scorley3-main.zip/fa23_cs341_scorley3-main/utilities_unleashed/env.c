/**
 * utilities_unleashed
 * CS 341 - Fall 2023
 */
#include "format.h"
#include "string.h"
#include <signal.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

int main(int argc, char *argv[]) {
    if (argc < 2) {
        print_env_usage();
        return 0;
    }

    int i;
    for (i = 1; i < argc; i++) {
        if (strcmp("--", *(argv + i)) == 0) break;
        if (i == argc - 1 || strchr(*(argv + i), '=')  == NULL) {
            print_env_usage();
            return 0;
        }
    }
    i = 1;
    pid_t pid = fork();
    if (pid == 0) {
        while(i < argc) {
            DEBUG_PRINT("parameter: %s \n", argv[i]);
            if (strcmp("--", argv[i]) == 0) {
                DEBUG_PRINT("into loop %s \n", argv[i]);
                execvp(*(argv + i + 1), argv + i +  1);
                print_exec_failed();
                exit(1);
            }
            //iterate through the parameter and set env
            //make sure to check for %
            // set equals pointer to getenv if there is a percent

            char * equals = strchr(argv[i], '=');
            *equals = '\0';
            equals++;
            DEBUG_PRINT("var %s \n", argv[i]);
            DEBUG_PRINT("equals %s \n", equals);
            if (*equals == '%') {
                equals++;
                char * val = getenv(equals);
                if (val == NULL) val = "";
                if (setenv(argv[i], val, 1) != 0) {
                    print_environment_change_failed();
                    exit(1);
                }
            }
            else if (setenv(argv[i], equals, 1) != 0) {
                print_environment_change_failed();
                exit(1);
            }

            i++;
        }
    }
    else if (pid > 0) {
                int status = 0;
                waitpid(pid, &status, 0);
                if (WEXITSTATUS(status)) {
                    exit(1);
                }
            }
    else {
        print_fork_failed();
    }

    return 0;
}
