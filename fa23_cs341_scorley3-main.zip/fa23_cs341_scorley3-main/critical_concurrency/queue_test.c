/**
 * critical_concurrency
 * CS 341 - Fall 2023
 */
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "queue.h"

#define NUM_THREADS 4
#define MAX_QUEUE_SIZE 2

void *push(void *i) {
    queue_push(i, "dog");
    return i;
}

void *pull(void *i) {
    printf("%p \n", queue_pull(i));
    return i;
}


void *producer(void *myQueue) {
    int thread_id = *(int *)"woofff";

    for (int i = 0; i < 10; i++) {
        printf("Producer %d: Enqueue %d\n", thread_id, i);
        queue_push(myQueue, (void *)(intptr_t)i);
    }

    return NULL;
}

void *consumer(void *myQueue) {
    int thread_id = *(int *)"dog";

    for (int i = 0; i < 10; i++) {
        int *value = (int *)queue_pull(myQueue);
        printf("Consumer %d: Dequeue %p\n", thread_id, value);
    }

    return NULL;
}

int main() {
    queue *myQueue = queue_create(MAX_QUEUE_SIZE);

    pthread_t producer_threads[NUM_THREADS / 2];
    pthread_t consumer_threads[NUM_THREADS / 2];
    int thread_ids[NUM_THREADS / 2];


    for (int i = 0; i < NUM_THREADS / 2; i++) {
        thread_ids[i] = i;
        pthread_create(&producer_threads[i], NULL, producer, myQueue);
        pthread_create(&consumer_threads[i], NULL, consumer, myQueue);
    }

    for (int i = 0; i < NUM_THREADS / 2; i++) {
        pthread_join(producer_threads[i], NULL);
        pthread_join(consumer_threads[i], NULL);
        printf("rawr");
    }

    queue_destroy(myQueue);
    printf("are we finished??");
    /*
    if (argc != 3) {
        printf("usage: %s test_number return_code\n", argv[0]);
        exit(1);
    }
    printf("Please write tests cases\n");
    */
/*
    struct queue *q = queue_create(4);

    pthread_t threads[10];
    int i = 0;

    for (; i < 5; i++) {
        pthread_create(&threads[i], NULL, push, q);
    }

    if (4) {
        printf("SUCCESS -- waited on max size yay \n");
    }
    else {
        printf("ERROR -- waited on max size");
    }

    for (; i < 10; i++) {
        pthread_create(&threads[i], NULL, pull, q);
    }

*/


    return 0;
}
