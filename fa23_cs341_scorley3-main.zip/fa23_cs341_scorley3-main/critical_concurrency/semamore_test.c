/**
 * critical_concurrency
 * CS 341 - Fall 2023
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "semamore.h"

void *post(void * s) {
    semm_post(s);
    semm_post(s);
    return s;
}

void *wait(void *s) {
    semm_wait(s);
    return s;
}

int main(int argc, char **argv) {
    Semamore *s = malloc(sizeof(Semamore));

    semm_init(s, 4, 10);

    if (s->value == 4 && s->max_val == 10) {
        printf("SUCCESS -- initialize value \n");
    }
    else {
        printf("ERROR -- initialize value \n");
    }

    semm_post(s);

    if (s->value == 5) {
        printf("SUCCESS -- single thread post \n");
    }
    else {
        printf("ERROR -- single thread post \n");
    }

    semm_wait(s);

    if (s->value == 4) {
        printf("SUCCESS -- single thread wait \n");
    }
    else {
        printf("ERROR -- single thread wait \n");
    }

    pthread_t threads[10];
    int i = 0;

    for (; i < 5; i++) {
       pthread_create(&threads[i], NULL, post, s);
     //printf("current value: %d \n", s->value);
   }

    for (; i < 10; i++) {
      //printf("current value: %d \n", s->value);
     pthread_create(&threads[i], NULL, wait, s);
    }

    //printf("current value: %d \n", s->value);

    for (i = 0; i < 10; i++) {
        pthread_join(threads[i], NULL);
        //printf("current value: %d \n", s->value);
    }

    if (s->value == 9) {
        printf("SUCCESS -- plus and minus \n");
    }
    else {
        printf("ERROR -- value is %d \n", s->value);
    }
    return 0;
}
