/**
 * mini_memcheck
 * CS 341 - Fall 2023
 */
#include "mini_memcheck.h"
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

size_t total_memory_requested;
size_t total_memory_freed;
size_t invalid_addresses;
meta_data *head;

void *mini_malloc(size_t request_size, const char *filename,
                  void *instruction) {
    if (request_size <= 0) return NULL;
    total_memory_requested += request_size;
    void * ptr = malloc(sizeof(meta_data) + request_size);
    meta_data * meta = (meta_data *) ptr;
    meta->request_size = request_size;
    meta->filename = filename;
    meta->instruction = instruction;

    meta->next = head;
    head = meta;
    DEBUG_PRINT("%s with %lu bytes \n", "successful malloc", request_size);
    return ptr + sizeof(meta_data);
}

void *mini_calloc(size_t num_elements, size_t element_size,
                  const char *filename, void *instruction) {
    if (num_elements == 0 || element_size == 0) return NULL;

    void * toReturn = mini_malloc(num_elements * element_size, filename, instruction);
    char * toEdit = toReturn;

    memset(toEdit, 0, num_elements * element_size);
    DEBUG_PRINT("%s of %lu bytes \n", "successful calloc", num_elements * element_size);
    return toReturn;
}

void *mini_realloc(void *payload, size_t request_size, const char *filename,
                   void *instruction) {
    if (payload == NULL) return mini_malloc(request_size, filename, instruction);
    if (request_size == 0) {
        mini_free(payload);
        return NULL;
    }

    meta_data * meta = payload - sizeof(meta_data);
    meta_data * oldMeta = meta;

    meta_data * checkValid = head;
    while (checkValid) {
        if (checkValid == meta) break;
        checkValid = checkValid->next;
    }

    if (!checkValid) {
        invalid_addresses++;
        return NULL;
    }

    DEBUG_PRINT("metadata: %p \n", meta);

    if (meta->request_size > request_size) {
        total_memory_freed += meta->request_size - request_size;
        meta->request_size = request_size;
        meta = realloc(meta, request_size + sizeof(meta_data));
        DEBUG_PRINT("meta: %p \n", meta);

    }
    else if (meta->request_size < request_size) {
        total_memory_requested += request_size - meta->request_size;
        meta->request_size = request_size;
        meta = realloc(meta, request_size + sizeof(meta_data));
        DEBUG_PRINT("meta: %p \n", meta);
    }

    if (head == oldMeta) {
        meta->next = head->next;
        head = meta;
    }
    else {
        meta_data * temp = head;
        while (temp->next != oldMeta) {
            temp = temp->next;
        }
        temp->next = meta;
    }
    DEBUG_PRINT("%s to %lu bytes \n", "successful realloc", request_size);
    return meta + 1;
}

void mini_free(void *payload) {
    if (payload == NULL) return;
    else {
        meta_data *temp = head;
        if (!temp) {
            invalid_addresses++;
            return;
        }

        if ((char *)(temp) + sizeof(meta_data) == payload) {
            total_memory_freed += temp->request_size;
            DEBUG_PRINT("head temp: %p, payload: %p \n", (char *)(temp) + sizeof(meta_data), payload);
            head = head->next;
            free(temp);
            DEBUG_PRINT("%s \n", "successful free");
            return;
        }
        while (temp->next != NULL) {
            DEBUG_PRINT("pointer: %p \n", temp);
            if ((char *)(temp->next) + sizeof(meta_data) == payload) {
                total_memory_freed += temp->next->request_size;
                meta_data * toDelete = temp->next;
                temp->next = toDelete->next;
                free(toDelete);
                DEBUG_PRINT("%s \n", "successful free");
                return;
            }
            else temp = temp->next;
        }

        invalid_addresses++;
    }
    DEBUG_PRINT("%s\n", "nothing was freed");
}
