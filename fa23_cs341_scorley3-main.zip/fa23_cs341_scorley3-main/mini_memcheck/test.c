/**
 * mini_memcheck
 * CS 341 - Fall 2023
 */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Your tests here using malloc and free
    char *word = malloc(100);
    char *word2 = calloc(4, 4);
    int * dog =  malloc(4);

    dog = realloc(dog, 12);

    word = realloc(word, 400);
    void * woofers = calloc(3, 12);
    woofers = realloc(woofers, 20);

    double * meow = malloc(16);

    realloc(meow + 1, 19);

    free(word + 1);
    free(word);
    free(word2);
    free(word2);
    free(dog);
    free(woofers);
    return 0;
}
