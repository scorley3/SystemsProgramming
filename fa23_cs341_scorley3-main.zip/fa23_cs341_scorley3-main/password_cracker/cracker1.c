/**
 * password_cracker
 * CS 341 - Fall 2023
 */
#include "cracker1.h"
#include "libs/format.h"
#include "libs/utils.h"
#include "includes/queue.h"
#include <bits/pthreadtypes.h>
#include <pthread.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <crypt.h>
#include <stdio.h>
#include <sys/types.h>

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

queue *q;
bool keepGoing = true;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
int num_found = 0;
int num_notfound = 0;

typedef struct _to_crack {
    char *name;
    char *hash;
    char *first_few;
} to_crack;

typedef struct threadssss {
    pthread_t thread;
    int thread_id;
} thread_t;

int password_cracker(char *name, char *hash, char*first_few, int threadId) {
    DEBUG_PRINT("%s %d \n", "started to crack a password", threadId);
    struct crypt_data cdata;
    cdata.initialized = 0;

    double time = getThreadCPUTime();

    char *ending_password = strdup(first_few);
    int i = 0;
    while (*(first_few + i)) {
        if (*(first_few + i) == '.') {
            *(first_few + i) = 'a';
            *(ending_password + i) = 'z';
        }
        i++;
    }

    int count = 0;
    while (strcmp(first_few, ending_password) != 0) {
        count++;
        char * check_hash = crypt_r(first_few, "xx", &cdata);
        if (strcmp(hash, check_hash) == 0) {
            v1_print_thread_result(threadId, name, first_few, count, getThreadCPUTime() - time, 0);
            free(ending_password);
            return 0;
        }
        incrementString(first_few);
    }

    count++;
    char * check_hash = crypt_r(first_few, "xx", &cdata);
    if (strcmp(hash, check_hash) == 0) {
        v1_print_thread_result(threadId, name, first_few, count, getThreadCPUTime() - time, 0);
        free(ending_password);
        return 0;
    }

    v1_print_thread_result(threadId, name, first_few, count, getThreadCPUTime() - time, 1);
    free(ending_password);
    return 1;
}


bool separate_password() {
    char *input = NULL;
    size_t bytes = 0;
    ssize_t bytes_read = 0;

    if ((bytes_read = getline(&input, &bytes, stdin)) <= 0) {
        free(input);
        return false;
    }

    input[bytes_read - 1] = '\0';

    to_crack *password = malloc(sizeof(to_crack));

    password->name = input;

    password->hash = strchr(input, ' ');
    *(password->hash) = 0;
    (password->hash)++;


    password->first_few = strchr(password->hash, ' ');
    *(password->first_few) = 0;
    (password->first_few)++;

    queue_push(q, password);
    return true;

}
void *wait(void *cv) {
    to_crack *input = NULL;
    while ((input = queue_pull(q)) != NULL) {
        int passed = password_cracker(input->name, input->hash, input->first_few, *(int *)(cv));
        free(input->name);
        free(input);
        if (passed) {
            num_notfound++;
        }
        else {
            num_found++;
        }
    }
    return NULL;
}
int start(size_t thread_count) {
    q = queue_create(-1);
    DEBUG_PRINT("%s", "started the start function \n");
    pthread_t threads[thread_count];
    int index[thread_count];


    for (size_t i = 0; i < thread_count; i++) {
        index[i] = i + 1;
        pthread_create(&threads[i], NULL, wait, &index[i]);
    }


    while (separate_password()) {
        //do nothing
    }

    int t = 0;
    while (t < 100) {
        queue_push(q, NULL);
        t++;
    }

    while (thread_count > 0) {
        pthread_join(threads[thread_count - 1], NULL);
        thread_count--;
    }

    v1_print_summary(num_found, num_notfound);
    queue_destroy(q);
    return 0; // DO NOT change the return code since AG uses it to check if your
              // program exited normally
}
