/**
 * password_cracker
 * CS 341 - Fall 2023
 */
/**
 * this file exists so that we can provide a main method which does a variety of
 * handy things
 */

#include <stddef.h>

// entry point for student code
int start(size_t thread_count);
