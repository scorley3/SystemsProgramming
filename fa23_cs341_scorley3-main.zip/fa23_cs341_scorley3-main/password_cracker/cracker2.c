/**
 * password_cracker
 * CS 341 - Fall 2023
 */
#include "cracker2.h"
#include "libs/format.h"
#include "libs/utils.h"
#include "includes/queue.h"
#include "libs/thread_status.h"
#include <bits/pthreadtypes.h>
#include <crypt.h>
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _to_crack {
    char *name;
    char *hash;
    char *first_few;
    int state;
} to_crack;


// 0 = cracked password
// 1 = thread stopped early
// 2 = thread has failed to find password (end)
// 3 = currently running

typedef struct _chunker {
    to_crack *pass_task;
    int state;
    size_t prefixLength;
    size_t threadId;
    long startIter;
    long numToCrack;

} chunker;

int count = 0;
int number_passed = 0;
int number_failed = 0;
bool keepGoing;
char *password = NULL;
pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t check_flag_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;

/*
void *threadFunc(void *nothing) {

    return NULL;
}
*/
to_crack *separate_password() {
    char *input = NULL;
    size_t bytes = 0;
    ssize_t bytes_read = 0;

    if ((bytes_read = getline(&input, &bytes, stdin)) <= 0) {
        free(input);
        return NULL;
    }

    input[bytes_read - 1] = '\0';

    to_crack *password = malloc(sizeof(to_crack));

    password->name = input;

    password->hash = strchr(input, ' ');
    *(password->hash) = 0;
    (password->hash)++;


    password->first_few = strchr(password->hash, ' ');
    *(password->first_few) = 0;
    (password->first_few)++;

    password->state = 0;
    return password;

}

void *work(void *task) {
    threadStatusSet("workinggggg");
    struct crypt_data cdata;
    cdata.initialized = 0;

    // what do i want to do in this function
    // i need to start at some number
    // end at some number
    // and track the current state of the the thingy
    // i need to add some fields to the job structure
    // or maybe make a new struct altogether
    // need to determine the starting and ending string for each
    chunker *chunk = task;
    char *starter_pass = strdup(chunk->pass_task->first_few);

    setStringPosition(starter_pass, chunk->startIter);
        size_t i = 0;
    while (i < chunk->prefixLength) {
        *(starter_pass + i) = *(chunk->pass_task->first_few + i);
        i++;
    }

    v2_print_thread_start(chunk->threadId, chunk->pass_task->name, chunk->startIter, starter_pass);

    int counter = 0;
    while (counter < chunk->numToCrack) {
        pthread_mutex_lock(&count_mutex);
        count++;
        pthread_mutex_unlock(&count_mutex);
        counter++;

        char *hash = crypt_r(starter_pass, "xx", &cdata);
        //`printf("%s \n", starter_pass);
        if (strcmp(hash, chunk->pass_task->hash) == 0) {
            chunk->state = 0;
            keepGoing = false;
            pthread_mutex_lock(&print_mutex);
            v2_print_thread_result(chunk->threadId, counter, 0);
            pthread_mutex_unlock(&print_mutex);
            password = starter_pass;
            return NULL;
        }
        incrementString(starter_pass);

        pthread_mutex_lock(&check_flag_mutex);
        if (!keepGoing) {
            pthread_mutex_unlock(&check_flag_mutex);
            chunk->state = 1;

            pthread_mutex_lock(&print_mutex);

            v2_print_thread_result(chunk->threadId, counter, 1);
            pthread_mutex_unlock(&print_mutex);
            free(starter_pass);
            return NULL;
        }
        pthread_mutex_unlock(&check_flag_mutex);
    }


    pthread_mutex_lock(&print_mutex);
    v2_print_thread_result(chunk->threadId, counter, 2);
    pthread_mutex_unlock(&print_mutex);
    free(starter_pass);
    return NULL;
}

int start(size_t thread_count) {
    pthread_t threads[thread_count];

    chunker chunks[thread_count];

    to_crack *pass_task = NULL;
    while ((pass_task = separate_password())) {
        double time = getTime();
        double CPUtime = getCPUTime();

        keepGoing = true;

        pthread_mutex_lock(&print_mutex);
        v2_print_start_user(pass_task->name);
        pthread_mutex_unlock(&print_mutex);


        size_t letters = strlen(pass_task->first_few) - getPrefixLength(pass_task->first_few);
        //printf("first few: %s letters: %lu \n", pass_task->first_few, letters);
        size_t i = 0;

        size_t total_count = 1;


        while (i < letters) {
            total_count *= 26;
            i++;
        }


        // need to make our chunks
        for (i = 0; i < thread_count; i++) {
            chunks[i].threadId = i + 1;
            chunks[i].pass_task = pass_task;
            chunks[i].prefixLength = getPrefixLength(pass_task->first_few);
            chunks[i].state = 3;
            getSubrange(letters, thread_count, i + 1, &chunks[i].startIter, &chunks[i].numToCrack);
        }

       //        size_t start = 0;
  //      size_t end = interval;

        for (i = 0; i < thread_count; i++) {
            pthread_create(&threads[i], NULL, work, &chunks[i]);
        }

        for (i = 0; i < thread_count; i++) {
            pthread_join(threads[i], NULL);
        }

        int result = 1;
        for (i = 0; i < thread_count; i++) {
            if (chunks[i].state == 0) {
                result = 0;
            }
        }

        v2_print_summary(pass_task->name, password, count, getTime() - time, getCPUTime() - CPUtime, result);
        if (password) {
            free(password);
            password = NULL;
        }
        free(pass_task->name);
        free(pass_task);
    }

    // TODO your code here, make sure to use thread_count!
    // Remember to ONLY crack passwords in other threads
    return 0; // DO NOT change the return code since AG uses it to check if your
     // program exited normally

}
