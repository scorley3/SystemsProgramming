/**
 * teaching_threads
 * CS 341 - Fall 2023
 */
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "reduce.h"
#include "reducers.h"

/* You might need a struct for each task ... */

/* You should create a start routine for your threads. */

typedef struct {
    int *list;
    int baseCase;
    int chunkSize;
    reducer reduceFunc;
    int result;
    int listLen;
} thread_data_t;

void *reduceChunk(void *arg) {
    thread_data_t *threadData = (thread_data_t *) arg;
    int startingIndex = threadData->result * threadData->chunkSize;
    int chunkSize = threadData->chunkSize;

    if (threadData->listLen - startingIndex - chunkSize < threadData->chunkSize) {
        chunkSize = threadData->listLen - startingIndex;
    }

    threadData->result = threadData->baseCase;
    int i;
    for (i = startingIndex; i < startingIndex + chunkSize; i++) {
        threadData->result = threadData->reduceFunc(threadData->result, threadData->list[i]);
    }


    pthread_exit(NULL);
}

int par_reduce(int *list, size_t list_len, reducer reduce_func, int base_case,
               size_t num_threads) {
    if (num_threads > list_len) {
        num_threads = list_len / 2;
    }

    int chunkSize = list_len / num_threads;
    pthread_t threadArray[num_threads];
    thread_data_t threadData[num_threads];

    size_t index = 0;
    for (; index < num_threads; index++) {
        threadData[index].list = list;
        threadData[index].chunkSize = chunkSize;
        threadData[index].baseCase = base_case;
        threadData[index].reduceFunc = reduce_func;
        threadData[index].result = index;
        threadData[index].listLen = list_len;

        pthread_create(&threadArray[index], NULL, reduceChunk, &threadData[index]);
    }

    for (index = 0; index < num_threads; index++) {
        pthread_join(threadArray[index], NULL);
    }

    int result = base_case;
    for (index = 0; index < num_threads; index++) {
        result = reduce_func(result, threadData[index].result);
    }
    return result;
}
