/**
 * nonstop_networking
 * CS 341 - Fall 2023
 */
#include "common.h"
#include "format.h"
#include "includes/vector.h"
#include <arpa/inet.h>
#include <asm-generic/socket.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define MAXEVENTS 100

// static variable declarations
static int serverRunning = 1;
static vector *files;
static char *tempName;
// end static variable declarations

// function declarations
void close_server();
void run_server(char *port);
void setup_sigint();

verb parse_verb();
void process_request(verb queryVerb);
void create_response();

void handle_get(int client);
void handle_put(int client);
void handle_delete(int client);
void handle_list(int client);
// end function declarations

int main(int argc, char **argv) {
    if (argc != 2) {
        print_server_usage();
        exit(1);
    }

    char *port = argv[1];

    setup_sigint();

    char exes[7] = "XXXXXX\0";
    char *tempDir = mkdtemp(exes);
    tempName = tempDir; // this may be a malloc issue
    print_temp_directory(tempDir);

    chdir(tempDir);

    files = string_vector_create(); // i think this is right because we want to maintain a list

    run_server(port);

    LOG("unlinking files");
    for (size_t i = 0; i < vector_size(files); i++) {
        unlink((char *) vector_get(files, i));
    }

    LOG("%s", tempDir);
    // probably need to use unlink
    chdir("..");
    rmdir(tempDir);
    perror(NULL);
    LOG("ending server");
    // may need to add check if port is < 1024 --> unsure
    vector_destroy(files);
    return 0;
}

void run_server(char *port) {
    LOG("starting to run server");
    struct addrinfo hints, *result; // declare addrinfo structs
    memset(&hints, 0, sizeof(hints)); // set hints to 0

    // set properties for server sock
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    // error check for get addr info
    int status = getaddrinfo(NULL, port, &hints, &result);
    if (status != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(status));
        freeaddrinfo(result);
        return;
    }

    int sock = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (sock == -1) {
        perror(NULL);
        freeaddrinfo(result);
        return;
    }

    // set socket options
    int optval = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));
    setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    // bind socket and check for errors
    if (bind(sock, result->ai_addr, result->ai_addrlen) != 0) {
        perror(NULL);
        freeaddrinfo(result);
        return;
    }


    if (listen(sock, 100) != 0) { // may need to change this number
        perror(NULL);
        freeaddrinfo(result);
        return;
    }

    LOG("server sock listening... time to create epoll fd");

    // set up epoll file descriptor
    int epoller = epoll_create1(0); // size arg ignored but must be > 0 (man page)
    if (epoller == -1) {
        perror("epoll_create(): ");
    }

    struct epoll_event event, events[MAXEVENTS];

    // set up socket as epoll event
    event.events = EPOLLIN;
    event.data.fd = sock;

    LOG("adding server sock to epoll fd");
    // add server socket to epoller
    if (epoll_ctl(epoller, EPOLL_CTL_ADD, sock, &event) == -1) {
        perror("epoll_ctl(): ");
        freeaddrinfo(result);
        return;
    }


    // need to use non-blocking I/O

    while (serverRunning) {
        LOG("epoll_wait!!!");
        int numReady = epoll_wait(epoller, events, MAXEVENTS, -1);
        LOG("epoll_wait is finished!!!");
        if (numReady == -1) {
            perror("epoll_wait(): ");
            freeaddrinfo(result);
            return;
        }

        // else iterate through the events that we found
        for (int n = 0; n < numReady; n++) {
            if (events[n].data.fd == sock) {
                int clientSock = accept(sock, (struct sockaddr *) result, &result->ai_addrlen);
                if (clientSock == -1) {
                    perror("accept");
                    freeaddrinfo(result);
                    return;
                }

                fcntl(clientSock, F_SETFL, O_NONBLOCK);
                event.events = EPOLLIN | EPOLLET;
                event.data.fd = clientSock;
                if (epoll_ctl(epoller, EPOLL_CTL_ADD, clientSock, &event) == -1) {
                    perror("epoll_ctl");
                    freeaddrinfo(result);
                    return;
                }
            }
            else {
                // handle event??
                // 1. process request
                // 2. create response
                // 3. write response to socket
                // 4. done
                // do a write all to socket somewhere in here
                int clientSock = events[n].data.fd;
                char verbBuffer[4];
                read_all_from_socket(clientSock, verbBuffer, 4);
                LOG("here is our verb buffer: %s \n", verbBuffer);
                if (!strncmp(verbBuffer, "GET ", 4)) {
                    handle_get(clientSock);
                }
                else if (!strncmp(verbBuffer, "LIST", 4)) {
                    handle_list(clientSock);
                }
                else if (!strncmp(verbBuffer, "PUT ", 4)) {
                    handle_put(clientSock);
                }
                else if (!strncmp(verbBuffer, "DELE", 4)) {
                    handle_delete(clientSock);
                }
                else {
                    write_all_to_socket(clientSock, "ERROR\n", 6);
                    write_all_to_socket(clientSock, err_bad_request, strlen(err_bad_request));
                }

                epoll_ctl(epoller, EPOLL_CTL_DEL, clientSock, NULL);
                close(clientSock);
            }
        }

    }

    freeaddrinfo(result);
    LOG("ending server");

}

void handle_put(int client) {
    // need to have buffer of size 1024
    // read into that buffer
    // process line
    // if more after line, read size and data
    // else invalid
    // do we want to malloc????

    // 1. malloc buffer
    // 2. read 1024 bytes from socket
    // 3. read first line
    // 4. create file
    // 5. read size of file from buffer
    // 6. read data in buffer into file
    // 7. while read all from socket != 0 and bytes < size
    // a. read 1024 bytes into buffer
    // b. read buffer into file

    char *putBuffer = malloc(1025);
    LOG("%p", putBuffer);
    memset(putBuffer, 0, 1024);

    ssize_t bytes = 0;
    bytes = read_all_from_socket(client, putBuffer, 1024);
    char *endOfLine = strchr(putBuffer, '\n');
    if (!endOfLine) {
        write_all_to_socket(client, "ERROR\n", 6);
        write_all_to_socket(client, err_bad_request, strlen(err_bad_request));
        free(putBuffer);
        return;
    }
    *endOfLine = 0;
    endOfLine++;

    LOG("filename: %s", putBuffer);
    char *fileName = malloc(strlen(putBuffer) + 1);
    strcpy(fileName, putBuffer);
    FILE *newFile = fopen(fileName, "w+");

    // may be an off by one error here --> tbd
    if (endOfLine - putBuffer == bytes) {
        endOfLine = putBuffer;
        int count = 0;
        while((bytes = read_all_from_socket(client, putBuffer, 1024)) == 0) {
            endOfLine = putBuffer;
            count++;
            if (count > 200) {
                free(putBuffer);
                fclose(newFile);
                remove(fileName);
                free(fileName);
                return;
            }
        }
    }
    ssize_t size = 0;
    memcpy(&size, endOfLine, sizeof(size_t));
    LOG("size of file: %lu", size);
    endOfLine += sizeof(size_t);



    LOG("%lu %lu", bytes, endOfLine - putBuffer);
    bytes -= (endOfLine - putBuffer); // subtract number of bytes already processed
    // need to deal with header being sent before data
    // how to wait on the delay???
    if (bytes < 0 || bytes > 1020) {
        bytes = 0;
    }

    fwrite(endOfLine, sizeof(char), bytes, newFile);


    LOG("wrote %lu initial bytes to file: %s", bytes, endOfLine);
    LOG("is bytes == size? %lu %lu", bytes, size);

    while (bytes < size) {
        memset(putBuffer, 0, 1025);
        ssize_t bytesRead = read_all_from_socket(client, putBuffer, 1024);
        if (bytes + bytesRead > size) {
            LOG("bytes read is 0 or we are adding too many bytes");
            write_all_to_socket(client, "ERROR\n", 6);
            write_all_to_socket(client, err_bad_file_size, strlen(err_bad_file_size));
            free(putBuffer);
            fclose(newFile);
            remove(fileName);
            free(fileName);
            return;
        }

        fwrite(putBuffer, sizeof(char), bytesRead, newFile);
        bytes += bytesRead;
        LOG("just wrote %lu bytes to the new file: %s", bytesRead, putBuffer);

        if (bytes == size) break;
    }

    //fwrite("\0", sizeof(char), 1, newFile);

    int found = 0;
    for (size_t i = 0; i < vector_size(files); i++) {
        LOG("checking for file with %s, %s", (char *) vector_get(files, i), fileName);
        if (!strcmp((char *) vector_get(files, i), fileName)) {
            found = 1;
            break;
        }
    }

    LOG("found is %d", found);
    if (!found) vector_push_back(files, fileName);
    free(fileName);
    free(putBuffer);
    fclose(newFile);

    write_all_to_socket(client, "OK\n", 3);


}

void handle_get(int client) {
    char *getBuffer = malloc(1025);
    ssize_t bytes = read_all_from_socket(client, getBuffer, 1024);
    if (bytes <= 0) {
        write_all_to_socket(client, "ERROR\n", 6);
        free(getBuffer);
        return;
    }

    char *endOfFileName = strchr(getBuffer, '\n');
    if (endOfFileName) *endOfFileName = 0;
    LOG("get file name: %s", getBuffer);

    int found = 0;
    for (size_t i = 0; i < vector_size(files); i++) {
        LOG("checking for file with %s, %s", (char *) vector_get(files, i), getBuffer);
        if (!strcmp((char *) vector_get(files, i), getBuffer)) {
            found = 1;
            break;
        }
    }

    LOG("did we find the file?: %d", found);

    if (!found) {
        write_all_to_socket(client, "ERROR\n", 6);
        write_all_to_socket(client, err_no_such_file,  strlen(err_no_such_file));
        free(getBuffer);
        return;

    }

    FILE *file = fopen(getBuffer, "r+");
    if (!file) {
        write_all_to_socket(client, "ERROR\n", 6);
        write_all_to_socket(client, err_no_such_file, strlen(err_no_such_file));
        free(getBuffer);
        return;
    }

    write_all_to_socket(client, "OK\n", 3);

    fseek(file, 0, SEEK_END); // go to end
    size_t fileLength = ftell(file); // get length
    fseek(file, 0, SEEK_SET); // go to beginning

    ssize_t bytesRead = write_all_to_socket(client, (char *)&fileLength, sizeof(size_t)); // write file length to socket

    if (bytesRead == -1 || bytesRead == 0) {
        write_all_to_socket(client, "ERROR\n", 6);
        write_all_to_socket(client, "Could not write file size", sizeof("Could not write file size"));
        return;
    }

    char *fileBody = malloc(1025);

    size_t bytesWritten = 0;
    while (bytesWritten < fileLength) {
       LOG("bytesWritten: %lu and file lenght: %lu", bytesWritten, fileLength);
       ssize_t bytesJustRead = fread(fileBody, sizeof(char), 1024, file);
       int status = write_all_to_socket(client, fileBody, bytesJustRead);
       LOG("status: %d and bytesJustRead: %lu", status, bytesJustRead);
       if (status == -1) break;
       bytesWritten += status;
       if (!status) break;
    }
    fclose(file);

    free(fileBody);
    free(getBuffer);

}

void handle_list(int client) {
    // finish reading from socket
    char buffer[1];
    read_all_from_socket(client, buffer, 1);

    char elements[1024];
    memset(&elements, 0, 1024);
    size_t size = 0;
    write_all_to_socket(client, "OK\n", 3);
    for (size_t i = 0; i < vector_size(files); i++) {
        strcat(elements, vector_get(files, i));
        strcat(elements, "\n");
        size += strlen(vector_get(files, i)) + 1;
    }

    write_all_to_socket(client, (char *)&size, sizeof(size_t));
    write_all_to_socket(client, elements, size);
}

void handle_delete(int client) {
    LOG("starting to delete a file");
    // finish reading verb and space
    char buffer[3];
    read_all_from_socket(client, buffer, 3);

    char *deleteBuffer = malloc(1025);
    ssize_t bytes = read_all_from_socket(client, deleteBuffer, 1024);
    if (bytes <= 0) {
        write_all_to_socket(client, "ERROR\n", 6);
        write_all_to_socket(client, err_bad_request, strlen(err_bad_request));
        free(deleteBuffer);
        return;
    }

    deleteBuffer[bytes] = 0;
    LOG("current delete buffer: %s", deleteBuffer);
    char *endOfFileName = strchr(deleteBuffer, ' ');
    if (endOfFileName) *endOfFileName = 0;
    else {
        endOfFileName = strchr(deleteBuffer, '\n');
        *endOfFileName = 0;
    }
    LOG("delete file name: %s %lu", deleteBuffer, strlen(deleteBuffer));

    int found = 0;
    for (size_t i = 0; i < vector_size(files); i++) {
        LOG("comparison of %s, %s", (char *) vector_get(files, i), deleteBuffer);
        LOG("%d", strcmp((char *) vector_get(files, i), deleteBuffer));
        if (!strncmp((char *) vector_get(files, i), deleteBuffer, strlen(vector_get(files, i)))) {
            vector_erase(files, i);
            found = 1;
            break;
        }
    }

    LOG("%d", found);
    if (found) {
        LOG("deleting file...");
        int deleteStatus = remove(deleteBuffer);
        LOG("with status %d", deleteStatus);
        perror("Delete: ");
        write_all_to_socket(client, "OK\n", 3);
    }
    else {
        write_all_to_socket(client, "ERROR\n", 6);
        write_all_to_socket(client, err_no_such_file, strlen(err_no_such_file));
    }
    free(deleteBuffer);
}

void close_server() {
    serverRunning = 0;
}

void setup_sigint() {
    struct sigaction action;
    memset(&action, 0, sizeof(action));
    sigaction(SIGPIPE, &action, NULL);
    action.sa_handler = close_server;
    if (sigaction(SIGINT, &action, NULL) < 0) {
        perror("sigaction");
        exit(1);
    }
    else {
        LOG("sigint set up successfully");
    }
}
