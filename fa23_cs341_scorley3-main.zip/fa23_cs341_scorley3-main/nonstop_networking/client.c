/**
 * nonstop_networking
 * CS 341 - Fall 2023
 */
#include "format.h"
#include <ctype.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <netdb.h>

#include "common.h"

#define EXTRABYTES 5

char **parse_args(int argc, char **argv);
verb check_args(char **args);
int send_command(int sock, verb queryVerb, char **args);
int proc_response(int sock, verb queryVerb, char **args);


int main(int argc, char **argv) {
    // Good luck!
    char **args = parse_args(argc, argv);
    verb queryVerb = check_args(args);

    int fd = connect_to_server(args[0], args[1]);

    int commandStatus = send_command(fd, queryVerb, args); // send command to server

    if (commandStatus) {
        print_error_message((char *) err_bad_request); // not sure if this is right
    }

    if (shutdown(fd, SHUT_WR) == -1) {
        perror(NULL); // not sure if this is right
    }

    proc_response(fd, queryVerb, args); // process response from server

    close(fd); // close the socket
    free(args);
    return 0;
}

ssize_t print_bytes(ssize_t bytes) {
   // printf("bytes written: %zu\n", bytes);
    return bytes;
}

int send_command(int sock, verb queryVerb, char **args) {
    // send query info
    char *commandHeader = calloc(1024, 1); // allocate memory for header

    strcpy(commandHeader, args[2]); // add verb

    if (queryVerb != LIST) { // add filename if not a LIST command
        strcat(commandHeader, " "); // add space
        strcat(commandHeader, args[3]); // add filename
    }
    strcat(commandHeader, "\n"); // add new line

    // send query contents
    ssize_t headerBytes = write_all_to_socket(sock, commandHeader, strlen(commandHeader));
    //printf("header: %s\n", commandHeader);
    print_bytes(headerBytes);
    free(commandHeader);

    if (queryVerb == PUT) {
        FILE *file = fopen(args[4], "r+");
        if (!file) {
            print_error_message((char *) err_no_such_file);
            exit(1);
        }

        fseek(file, 0, SEEK_END); // go to end
        size_t fileLength = ftell(file); // get length
        fseek(file, 0, SEEK_SET); // go to beginning

        ssize_t bytes = write_all_to_socket(sock, (char *)&fileLength, sizeof(size_t)); // write file length to socket

        LOG("adding size to request %lu", fileLength);
        if (bytes == -1 || bytes == 0) {
            print_invalid_response(); // unable to write
            exit(1);
        }
        print_bytes(bytes);
        char *fileBody = malloc(1025);

        size_t bytesWritten = 0;
        while (bytesWritten < fileLength) {
            memset(fileBody, 0, 1024);
            int bytesRead = fread(fileBody, sizeof(char), 1024, file);
            if (bytesRead == -1) break;
            LOG("how many bytes did we read? %d", bytesRead);
            int status = write_all_to_socket(sock, fileBody, bytesRead);
            print_bytes(status);

            LOG("writing bytes to server %d! total written: %lu", status, bytesWritten);
            bytesWritten += status;
            if (status == -1) break;

        }

        fclose(file);

        free(fileBody);

        return 0;


    }



    return 0; // comment out when done
}

void processListResponse(int sock) {
    size_t bytesToRead;
    read_all_from_socket(sock, (char *)&bytesToRead, sizeof(size_t));

    char *buffer = malloc(bytesToRead + 1);
    memset(buffer, 0, bytesToRead + 1);
    size_t bytesRead = read_all_from_socket(sock, buffer, bytesToRead);
    if (bytesRead > bytesToRead) print_received_too_much_data();
    else if (bytesRead < bytesToRead) print_too_little_data();
    else {
        printf("%s", buffer);
    }

    free(buffer);

}

void processGetResponse(int sock, char *filename) {
    //printf("filename: %s\n", filename);
    FILE *localFile = fopen(filename, "wb");
    chmod(filename, S_IRWXU | S_IRWXG | S_IRWXO);



    size_t fileSize = 0, bytesRead = 0;
    int status = read_all_from_socket(sock, (char *)&fileSize, sizeof(size_t));
    if (status == -1) {
        // print error
        exit(1);
    }
    char *buffer = malloc(1025);

    while (bytesRead < fileSize + EXTRABYTES) {
        int status = read_all_from_socket(sock, buffer, 1024);
       // printf("%s\n", buffer);
        bytesRead += status;
        LOG("bytes read: %lu, bytes needed: %lu", bytesRead, fileSize);
        fwrite(buffer, 1, status, localFile);
        if (bytesRead >= fileSize) break;
        if (!status) break;
    }

    if (bytesRead > fileSize) print_received_too_much_data();
    else if (bytesRead < fileSize) print_too_little_data();

    fclose(localFile);
    free(buffer);

}

void processErrorResponse(int sock, char *buff) {
     buff = realloc(buff, 7);
     read_all_from_socket(sock, buff + 3, 3);
     //printf("%s", buff);

     if (strcmp(buff, "ERROR\n") == 0) {
         buff = realloc(buff, 100);
         if (!read_all_from_socket(sock, buff, 100)) {
             print_connection_closed();
         }
         print_error_message(buff);
     }
     else {
         print_invalid_response();
     }
}

int proc_response(int sock, verb queryVerb, char **args) {
    char *buff = calloc(4, 1); // allocate bytes to check OK\n

    read_all_from_socket(sock, buff, 3); // read 3 bytes from socket

    if (!strcmp(buff, "OK\n")) {
        //printf("%s", buff); // delete later --> print out buffer

        if (queryVerb == PUT || queryVerb == DELETE) {
            print_success(); // we don't need to do anything else
        }
        else if (queryVerb == LIST) {
            processListResponse(sock); // print out the file names given in response
        }
        else if (queryVerb == GET) {
            processGetResponse(sock, args[4]); // store file data in local file
        }
        else {
            printf("this shouldn't be happening\n"); // will hit if verb has invalid value
        }
    }
    else if (!strcmp(buff, "ERR")) {
      processErrorResponse(sock, buff); // print out the error that we receive
    }
    else {
        print_invalid_response();
    }
    free(buff);
    return 0;
}

/**
 * Given commandline argc and argv, parses argv.
 *
 * argc argc from main()
 * argv argv from main()
 *
 * Returns char* array in form of {host, port, method, remote, local, NULL}
 * where `method` is ALL CAPS
 */
char **parse_args(int argc, char **argv) {
    if (argc < 3) {
        return NULL;
    }

    char *host = strtok(argv[1], ":");
    char *port = strtok(NULL, ":");
    if (port == NULL) {
        return NULL;
    }

    char **args = calloc(1, 6 * sizeof(char *));
    args[0] = host;
    args[1] = port;
    args[2] = argv[2];
    char *temp = args[2];
    while (*temp) {
        *temp = toupper((unsigned char)*temp);
        temp++;
    }
    if (argc > 3) {
        args[3] = argv[3];
    }
    if (argc > 4) {
        args[4] = argv[4];
    }

    return args;
}

/**
 * Validates args to program.  If `args` are not valid, help information for the
 * program is printed.
 *
 * args     arguments to parse
 *
 * Returns a verb which corresponds to the request method
 */
verb check_args(char **args) {
    if (args == NULL) {
        print_client_usage();
        exit(1);
    }

    char *command = args[2];

    if (strcmp(command, "LIST") == 0) {
        return LIST;
    }

    if (strcmp(command, "GET") == 0) {
        if (args[3] != NULL && args[4] != NULL) {
            return GET;
        }
        print_client_help();
        exit(1);
    }

    if (strcmp(command, "DELETE") == 0) {
        if (args[3] != NULL) {
            return DELETE;
        }
        print_client_help();
        exit(1);
    }

    if (strcmp(command, "PUT") == 0) {
        if (args[3] == NULL || args[4] == NULL) {
            print_client_help();
            exit(1);
        }
        return PUT;
    }

    // Not a valid Method
    print_client_help();
    exit(1);
}
