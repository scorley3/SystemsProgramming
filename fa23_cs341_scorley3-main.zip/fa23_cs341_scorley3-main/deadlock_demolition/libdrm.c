/**
 * deadlock_demolition
 * CS 341 - Fall 2023
 */
#include "includes/dictionary.h"
#include "includes/graph.h"
#include "includes/vector.h"
#include "libdrm.h"
#include "includes/set.h"
#include <bits/pthreadtypes.h>
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>

// need to figure out how to get tid
// need to decide what goes in each struct
//
struct drm_t {
    pthread_mutex_t m;
};

int one = 1;
int zero = 0;
static graph *g = NULL;
static pthread_mutex_t glock = PTHREAD_MUTEX_INITIALIZER;
// thread id function
//
size_t hash_thread(void *elem) {
    pthread_t *thread_id = elem;
    return *thread_id;

}

// used LLM to help with debugging of DFS function and code cleanup
bool has_cycle_recurse(void *thread_id, dictionary *map) {
    if (graph_vertex_degree(g, thread_id) == 0) {
        return false;
    }
    vector *neighbors = graph_neighbors(g, thread_id);
    dictionary_set(map, thread_id, &one);
    for (size_t i = 0; i < vector_size(neighbors); i++) {
        printf("%d \n", *(int *)dictionary_get(map, vector_get(neighbors, i)));
        if (*(int *)dictionary_get(map, vector_get(neighbors, i)) == 1) {
            return true;
        }
        else {
            bool hasCycle = has_cycle_recurse(vector_get(neighbors, i), map);
            if (hasCycle) return hasCycle;
        }
    }
    return false;
}

bool has_cycle(void *drm, void *thread_id){
    vector *vertex_vect = graph_vertices(g);
    dictionary *map = shallow_to_int_dictionary_create();
    dictionary_set(map, drm, &one);
    dictionary_set(map, thread_id, &one);
    size_t i = 0;
    for (; i < vector_size(vertex_vect); i++) {
        dictionary_set(map, vector_get(vertex_vect, i), &zero);
    }

    bool hasCycle = has_cycle_recurse(thread_id, map);
    printf("finished recursing ever with result %d \n", hasCycle);
    dictionary_destroy(map);
    return hasCycle;
}

drm_t *drm_init() {
    /* Your code here */
    // do graph create
    // need to create new graph with hash function and comparison function
    struct drm_t *drm = malloc(sizeof(struct drm_t));
    pthread_mutex_init(&(drm->m), NULL);
    if (g == NULL) {
        g = shallow_graph_create();
    }
    pthread_mutex_lock(&glock);
    graph_add_vertex(g, drm);
    pthread_mutex_unlock(&glock);

    return drm;
}

int drm_post(drm_t *drm, pthread_t *thread_id) {
    /* Your code here */
    // if edge in graph, unlock and get rid of edge
    // else do not unlock and return
    pthread_mutex_lock(&glock);
    if (graph_contains_vertex(g, thread_id)) {
        if (graph_adjacent(g, drm, thread_id)) {
            graph_remove_edge(g, drm, thread_id);
            pthread_mutex_unlock(&(drm->m));
            pthread_mutex_unlock(&glock);
            return 1;
        }
    }
    pthread_mutex_unlock(&glock);
    return 0;
}

int drm_wait(drm_t *drm, pthread_t *thread_id) {
    /* Your code here */
    // add thread to resource allocation graph if not already present
    // use tid as identifier (hash function)
    // add appropriate edge to RAG
    // check if lock would cause deadlock
    // if it would cause deadlock, return without locking
    // otherwise, lock the drm
    pthread_mutex_lock(&glock);
    if (!graph_contains_vertex(g, thread_id)) {
        graph_add_vertex(g, thread_id);
    }
    graph_add_edge(g, thread_id, drm);
    if (has_cycle(drm, thread_id)) {
        graph_remove_edge(g, thread_id, drm);
        pthread_mutex_unlock(&glock);
        return 0;
    }
    else {
        pthread_mutex_unlock(&glock);
        pthread_mutex_lock(&(drm->m));
        pthread_mutex_lock(&glock);
        graph_remove_edge(g, thread_id, drm);
        graph_add_edge(g, drm, thread_id);
        pthread_mutex_unlock(&glock);
        return 1;
    }
}

void drm_destroy(drm_t *drm) {
    /* Your code here */
    // deallocate resources
    graph_remove_vertex(g, drm);
    free(drm);
    return;
}

