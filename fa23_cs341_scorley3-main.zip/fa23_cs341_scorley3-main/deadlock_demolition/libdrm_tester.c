/**
 * deadlock_demolition
 * CS 341 - Fall 2023
 */
#include "libdrm.h"

#include <assert.h>
#include <bits/pthreadtypes.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void *wait(void *drm) {
    pthread_t *t = malloc(sizeof(pthread_t));
    *t = pthread_self();
    drm_wait(drm, t);
    free(t);
    return NULL;
}

void test_basic_mutex_functionality() {
    drm_t *drm = drm_init();
    unsigned long *d = malloc(sizeof(unsigned long));
    *d = 1;
    drm_wait(drm, d);
    assert(drm_post(drm, d));
    drm_destroy(drm);
    free(d);
}

void test_deadlock_prevention() {
    drm_t *mutex = drm_init();

    pthread_t thread1, thread2;
    int result1, result2;

    pthread_create(&thread1, NULL, wait, mutex);
    pthread_create(&thread2, NULL, wait, mutex);

    pthread_join(thread1, (void *)&result1);
    pthread_join(thread2, (void *)&result2);

    assert(result1 == 0);
    assert(result2 == -1);
    drm_destroy(mutex);
}

void test_concurrent_locking() {
    drm_t *mutex = drm_init();

    pthread_t thread1, thread2;
    int result1, result2;

    pthread_create(&thread1, NULL, wait, mutex);
    pthread_create(&thread2, NULL, wait, mutex);

    pthread_join(thread1, (void *)&result1);
    pthread_join(thread2, (void *)&result2);

    assert(result1 == 0);
    assert(result2 == 0);
    drm_destroy(mutex);
}

int main() {
    printf("start \n");
    test_basic_mutex_functionality();
    printf("test 1 passed \n");
    test_deadlock_prevention();
    printf("test 2 passed \n");
    test_concurrent_locking();
    printf("test 3 passed \n");
    /*
    pthread_t threads[10];
    drm_t *drm = drm_init();
    // TODO your tests here

    for (int i = 0; i < 10; i++) {
        pthread_create(&threads[i], NULL, func, drm);
    }


    drm_destroy(drm);
*/
    return 0;
}
