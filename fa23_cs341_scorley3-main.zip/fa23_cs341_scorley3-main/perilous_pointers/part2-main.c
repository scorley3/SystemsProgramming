/**
 * perilous_pointers
 * CS 341 - Fall 2023
 */
#include "part2-functions.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * (Edit this function to print out the "Illinois" lines in
 * part2-functions.c in order.)
 */
int main() {
    first_step(81);
    int * two = malloc(sizeof(int));
    *two = 132;
    second_step(two);
    free(two);
    two = NULL;

    int ** value = malloc(sizeof(int*));
    value[0] = malloc(sizeof(int));
    value[0][0] = 8942;
    double_step(value);

    free(value[0]);
    free(value);
    value = NULL;

    char* word = calloc(10, 1);
    word[5] = 15;
    strange_step(word);

    word[3] = 0;
    empty_step(word);

    word[3] = 'u';
    two_step(word, word);

    three_step(word, word + 2, word + 4);

    word[1] = 8;
    word[2] = 16; 
    word[3] = 24;
    step_step_step(word, word, word);

    word[0] = 5;
    int odd = 5;

    it_may_be_odd(word, odd); 

    char* commasep = malloc(8);
    strcpy(commasep, "d,CS241");
    tok_step(commasep);

    free(commasep);

    char* end = malloc(sizeof(int));
    end[0] = 1;
    end[1] = 2;
    end[2] = 3;
    end[3] = 0;
    the_end(end, end);

    free(end);
    free(word);
    word = NULL;
    
    return 0;
}
