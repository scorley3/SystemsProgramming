/**
 * parallel_make
 * CS 341 - Fall 2023
 */

#include "format.h"
#include "includes/graph.h"
#include "includes/vector.h"
#include "includes/set.h"
#include "parmake.h"
#include "parser.h"
#include "rule.h"
#include <bits/pthreadtypes.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>

// i literally cannot believe it deleted all my comments
//
// makefile contains many entries, each of which has:
// 1. target (usually a file)
// 2. dependencies (files which target depends on)
// 3. commands to run based on targets and dependencies
//
// graph and vector are not thread-safe!!!
//
// we only want to execute a rule if
// 1. name is not a file on disk
// 2. rule depends on a rule whose name is not a file on disk
// 3. rule is the name of a file on disk, and it depends on another file
// with a NEWER change time than the change time of the file which corresponds
// to the name of the rule. To determine whether a file is NEWER, you should
// use stat and difftime to determine if it is newer. The differences in
// time will have a granularity of 1 second.
//
// only execute each rule once
//
// don't execute a rule if it is in a cycle or if any of its parents are in a cycle
// if one rule fails, all its parent rules fail
// if a parent rule fails, the child rule can still go
//
//

// use state of node ?
//
// dependency states
// 0 --> default
// 1 --> failed
// 2 --> set but not run
// 3 --> running
// 4 --> success
//


#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif



#define STATE_DEFAULT 0
#define STATE_FAILED 1
#define STATE_CYCLE 5
#define STATE_READY 2
#define STATE_RUNNING 3
#define STATE_SUCCESS 4
#define STATE_SEEN 6

graph *makefileGraph;
vector *goal_rules;
pthread_mutex_t ruleLock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t goLock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv;
bool keepGoing = true;

void detect_cycle(rule_t *rule) {
    DEBUG_PRINT("detecting cycle %s \n", rule->target);
    if (rule->state != STATE_DEFAULT) {
        return;
    }
    rule->state = STATE_CYCLE;

    vector *dependencies = graph_neighbors(makefileGraph, rule->target);

    for (size_t i = 0; i < vector_size(dependencies); i++) {
        rule_t *dep = graph_get_vertex_value(makefileGraph, vector_get(dependencies, i));
        if (dep->state == STATE_CYCLE) {
            rule->state = STATE_FAILED;
            if (graph_adjacent(makefileGraph, "", rule->target)) {
                print_cycle_failure(rule->target);
            }
            vector_destroy(dependencies);

            return;
        }

        detect_cycle(dep);

        if (dep->state == STATE_FAILED && rule->state != STATE_FAILED) {
            rule->state = STATE_FAILED;
            if (graph_adjacent(makefileGraph, "", rule->target)) {
                print_cycle_failure(rule->target);
            }
            vector_destroy(dependencies);
            return;
        }
    }

    if (rule->state != STATE_FAILED) {
        rule->state = STATE_DEFAULT;
    }

    vector_destroy(dependencies);
}

// check if any of the dependencies is a fail
void check_dependencies(rule_t *rule) {
    DEBUG_PRINT("checking dependencies %s \n", rule->target);
    vector *dependencies = graph_neighbors(makefileGraph, rule->target);

    bool no_fails = true;
    bool waiting = false;

    for (size_t i = 0; i < vector_size(dependencies); i++) {
        rule_t *dep = graph_get_vertex_value(makefileGraph, vector_get(dependencies, i));
        DEBUG_PRINT("dependency with target %s and state %d \n", dep->target, dep->state);
        if (dep->state == STATE_FAILED) {
            no_fails = false;
            break;
        }
        else if (dep->state != STATE_SUCCESS) {
            if (dep->state == STATE_DEFAULT) {
                vector_push_back(goal_rules, dep->target);
                dep->state = STATE_SEEN;
            }
            waiting = true;
        }
    }

    if (!no_fails) {
        rule->state = STATE_FAILED;
    }
    else if (!waiting) {
        rule->state = STATE_READY;
    }

    vector_destroy(dependencies);
}


int run_rule(rule_t *rule) {
    DEBUG_PRINT("running rule %s \n", rule->target);
    struct stat time_check;
    stat(rule->target, &time_check);
    time_t updated = time_check.st_mtime;

    bool need_to_run = false;
    vector *dependencies = graph_neighbors(makefileGraph, rule->target);
    if (vector_size(dependencies) == 0 || access(rule->target, F_OK) == -1) {
        need_to_run = true;
    }
    else {
        for (size_t i = 0; i < vector_size(dependencies); i++) {
            rule_t *dep = graph_get_vertex_value(makefileGraph, vector_get(dependencies, i));
            if (access(dep->target, F_OK) == -1) {
                need_to_run = true;
                break;
            }
            else {
                stat(dep->target, &time_check);
                if (updated < time_check.st_mtime) {
                    need_to_run = true;
                    break;
                }
            }
        }
    }

    vector_destroy(dependencies);

    if (!need_to_run) {
        pthread_mutex_lock(&ruleLock);
        rule->state = STATE_SUCCESS;
        pthread_mutex_unlock(&ruleLock);
        return 2;
    }

    DEBUG_PRINT("run rule %s \n", rule->target);
    // return 1 on fail and 0 on pass
    vector *commands = rule->commands;
    pthread_mutex_lock(&ruleLock);
    rule->state = STATE_RUNNING;
    pthread_mutex_unlock(&ruleLock);

    for (size_t i = 0; i < vector_size(commands); i++) {
        int status = system(vector_get(commands, i));
        if (status) {
            pthread_mutex_lock(&ruleLock);
            rule->state = STATE_FAILED;
            pthread_mutex_unlock(&ruleLock);
            return 1;
        }
    }
    pthread_mutex_lock(&ruleLock);
    rule->state = STATE_SUCCESS;
    pthread_mutex_unlock(&ruleLock);
    return 0;
}

void *thread(void *arg) {
    while (1) {
        rule_t *toRun = NULL;
        pthread_mutex_lock(&ruleLock);
        while (1) {
            if (vector_size(goal_rules) == 0) {
                pthread_cond_broadcast(&cv);
                pthread_mutex_unlock(&ruleLock);
                pthread_exit(0);
            }

            for (size_t i = 0; i < vector_size(goal_rules); i++) {
                rule_t *rule = graph_get_vertex_value(makefileGraph, vector_get(goal_rules, i));
                int currState = rule->state;
                if (currState == STATE_READY) {
                    toRun = rule;
                    vector_erase(goal_rules, i);
                    break;
                }
                else if (currState == STATE_FAILED) {
                    vector_erase(goal_rules, i);
                }
                else if (currState == STATE_DEFAULT || currState == STATE_SEEN) {
                    check_dependencies(rule);
                    if (rule->state == STATE_READY) {
                        toRun = rule;
                        rule->state = STATE_RUNNING;
                        vector_erase(goal_rules, i);
                        break;
                    }
                    else if (rule->state == STATE_FAILED) {
                        vector_erase(goal_rules, i);
                    }
                }
                else if (currState == STATE_SUCCESS) {
                    vector_erase(goal_rules, i);
                }
                else if (currState == STATE_RUNNING) {
                    vector_erase(goal_rules, i);
                }
                else {
                    printf("%s %d \n", "this shouldn't be happening", rule->state);
                }
            }

            if (toRun == NULL) {
                if (vector_size(goal_rules) == 0) {
                    pthread_cond_broadcast(&cv);
                    pthread_mutex_unlock(&ruleLock);
                    pthread_exit(0);
                }
                pthread_cond_wait(&cv, &ruleLock);
            }
            else {
                break;
            }
        }
        pthread_mutex_unlock(&ruleLock);
        run_rule(toRun);
        pthread_cond_broadcast(&cv);
    }
}

int parmake(char *makefile, size_t num_threads, char **targets) {
    // good luck!
    pthread_t threads[num_threads];

    makefileGraph = parser_parse_makefile(makefile, targets);

    // get a vector with each of the rules that we want to execute
    goal_rules = graph_neighbors(makefileGraph, "");

    pthread_cond_init(&cv, NULL);

    for (size_t i = 0; i < vector_size(goal_rules); i++) {
        rule_t *rule = graph_get_vertex_value(makefileGraph, vector_get(goal_rules, i));
        detect_cycle(rule);
        if (rule->state == STATE_FAILED) {
            vector_erase(goal_rules, i);
        }
    }

    if (vector_size(goal_rules) == 0) {
        vector_destroy(goal_rules);
        graph_destroy(makefileGraph);
        return 0;
    }

    for (size_t j = 0; j < num_threads; j++) {
        pthread_create(&threads[j], NULL, thread, NULL);
    }

    for (size_t k = 0; k < num_threads; k++) {
        pthread_join(threads[k], NULL);
    }

    // clean up memory
    vector_destroy(goal_rules);
    graph_destroy(makefileGraph);
    return 0;
}
