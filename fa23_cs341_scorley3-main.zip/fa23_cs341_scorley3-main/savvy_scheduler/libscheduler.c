/**
 * savvy_scheduler
 * CS 341 - Fall 2023
 */
#include "libpriqueue/libpriqueue.h"
#include "libscheduler.h"

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "print_functions.h"

/**
 * The struct to hold the information about a given job
 */
typedef struct _job_info {
    int id;
    int arrival_num;
    int priority;
    double running_time;
    double running_time_left;
    double arrival_time;
    double start_time;
    double recent_start;

    /* TODO: Add any other information and bookkeeping you need into this
     * struct. */
} job_info;

// global variables start
// globals that we have already include pqueue (priority queue), pqueue_scheme (scheme),
// and comparision_func (comparer_t)
double waiting_time = 0;
double turnaround_time = 0;
double response_time = 0;
int num_jobs = 0;
double curr_start_time = 0;

// global variables end

void scheduler_start_up(scheme_t s) {
    switch (s) {
    case FCFS:
        comparision_func = comparer_fcfs;
        break;
    case PRI:
        comparision_func = comparer_pri;
        break;
    case PPRI:
        comparision_func = comparer_ppri;
        break;
    case PSRTF:
        comparision_func = comparer_psrtf;
        break;
    case RR:
        comparision_func = comparer_rr;
        break;
    case SJF:
        comparision_func = comparer_sjf;
        break;
    default:
        printf("Did not recognize scheme\n");
        exit(1);
    }
    priqueue_init(&pqueue, comparision_func);
    pqueue_scheme = s;
    // Put any additional set up code you may need here
}

static int break_tie(const void *a, const void *b) {
    return comparer_fcfs(a, b);
}

int comparer_fcfs(const void *a, const void *b) {
    job *jobA = (job *) a;
    job *jobB = (job *) b;
    job_info *infoA = jobA->metadata;
    job_info *infoB = jobB->metadata;

    if (infoA->arrival_time < infoB->arrival_time) return -1;
    else if (infoA->arrival_time > infoB->arrival_time) return 1;
    // TODO: Implement me!
    return 0;
}

int comparer_ppri(const void *a, const void *b) {
    // Complete as is
    return comparer_pri(a, b);
}

int comparer_pri(const void *a, const void *b) {
    // TODO: Implement me!
    job *jobA = (job *) a;
    job *jobB = (job *) b;
    job_info *infoA = jobA->metadata;
    job_info *infoB = jobB->metadata;
    if (infoA->priority < infoB->priority) return -1;
    else if (infoA->priority > infoB->priority) return 1;
    return break_tie(a, b);
}

int comparer_psrtf(const void *a, const void *b) {
    // TODO: Implement me!
    job *jobA = (job *) a;
    job *jobB = (job *) b;
    job_info *infoA = jobA->metadata;
    job_info *infoB = jobB->metadata;
    if (infoA->running_time_left < infoB->running_time_left) return -1;
    else if (infoA->running_time_left > infoB->running_time_left) return 1;
    return break_tie(a, b);
}

int comparer_rr(const void *a, const void *b) {
    // TODO: Implement me!
    job *jobA = (job *) a;
    job *jobB = (job *) b;
    job_info *infoA = jobA->metadata;
    job_info *infoB = jobB->metadata;
    if (infoA->recent_start < infoB->recent_start) return -1;
    else if (infoA->recent_start > infoB->recent_start) return 1;

    return break_tie(a, b);
}

int comparer_sjf(const void *a, const void *b) {
    // TODO: Implement me!
    job *jobA = (job *) a;
    job *jobB = (job *) b;
    job_info *infoA = jobA->metadata;
    job_info *infoB = jobB->metadata;
    if (infoA->running_time < infoB->running_time) return -1;
    else if (infoA->running_time > infoB->running_time) return 1;
    return break_tie(a, b);
}

// Do not allocate stack space or initialize ctx. These will be overwritten by
// gtgo
void scheduler_new_job(job *newjob, int job_number, double time,
                       scheduler_info *sched_data) {
    // TODO: Implement me!
    newjob->metadata = malloc(sizeof(job_info));
    job_info *info = newjob->metadata;
    info->arrival_num = num_jobs;
    info->id = job_number;
    info->priority = sched_data->priority;
    info->running_time = sched_data->running_time;
    info->running_time_left = sched_data->running_time;
    info->arrival_time = time;
    info->start_time = 0;
    info->recent_start = 0;

    priqueue_offer(&pqueue, newjob);
    // create job t and assign variables
}

job *scheduler_quantum_expired(job *job_evicted, double time) {
    // TODO: Implement me!
    if (!job_evicted) {
        curr_start_time = time;
        if (priqueue_size(&pqueue) != 0) {
            job *job = priqueue_poll(&pqueue);
            job_info *info = job->metadata;
            if (info->start_time == 0) info->start_time = time;
            info->recent_start = time;
            return job;
        }
    }
    else {
        job_info *info = job_evicted->metadata;
        info->running_time_left -= time - curr_start_time;
        curr_start_time = time;
        if (pqueue_scheme != PPRI && pqueue_scheme != PSRTF && pqueue_scheme != RR) {
            return job_evicted;
        }
        else if (pqueue_scheme == RR) {
            if (priqueue_size(&pqueue) != 0) {
                job *toRet = priqueue_poll(&pqueue);
                job_info *info = toRet->metadata;
                if (info->start_time == 0) info->start_time = time;
                info->recent_start = time;
                priqueue_offer(&pqueue, job_evicted);
                return toRet;
            }
            return job_evicted;
        }
        else {
            priqueue_offer(&pqueue, job_evicted);
            job *toRet = priqueue_poll(&pqueue);
            job_info *info = toRet->metadata;
            if (info->start_time == 0) info->start_time = time;
            info->recent_start = time;
            return toRet;
        }
    }
    return NULL;
}

void scheduler_job_finished(job *job_done, double time) {
    // add to turnaround, waiting, response
    //
    job_info *info = job_done->metadata;
    double turnaround = time - info->arrival_time;
    double wait = time - info->arrival_time - info->running_time;
    double response = info->start_time - info->arrival_time;
    // response time -->

    turnaround_time += turnaround;
    waiting_time += wait;
    response_time += response;
    num_jobs++;
    free(job_done->metadata);
}

static void print_stats() {
    fprintf(stderr, "turnaround     %f\n", scheduler_average_turnaround_time());
    fprintf(stderr, "total_waiting  %f\n", scheduler_average_waiting_time());
    fprintf(stderr, "total_response %f\n", scheduler_average_response_time());
}

double scheduler_average_waiting_time() {
    // TODO: Implement me!
    return waiting_time / num_jobs;
}

double scheduler_average_turnaround_time() {
    // TODO: Implement me!
    return turnaround_time / num_jobs;
}

double scheduler_average_response_time() {
    // TODO: Implement me!
    return response_time / num_jobs;
}

void scheduler_show_queue() {
    // OPTIONAL: Implement this if you need it!
}

void scheduler_clean_up() {
    priqueue_destroy(&pqueue);
    print_stats();
}
