/**
 * savvy_scheduler
 * CS 341 - Fall 2023
 */
int int_write(int fd, int arg);
int double_write(int fd, double arg);
int ptr_write(int fd, void *arg);
